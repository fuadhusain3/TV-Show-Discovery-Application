import 'package:flutter_test/flutter_test.dart';
import 'package:tvmaze_app/core/network/api_exception.dart';
import 'package:tvmaze_app/repositories/show_repository.dart';
import 'package:tvmaze_app/services/show_api_service.dart';

import 'helpers/fake_api_client.dart';

const _notFound = ApiException('Not found.', statusCode: 404);

void main() {
  late FakeApiClient client;
  late ShowRepository repo;

  setUp(() {
    client = FakeApiClient({
      '/shows': (q) => q!['page'] == 0
          ? [
              showJson(1, weight: 10),
              showJson(2, weight: 90),
              'garbage',
              {'name': 'no id'},
              showJson(3, weight: 50),
            ]
          : throw _notFound,
      '/search/shows': (_) => [
            {'score': 0.9, 'show': showJson(7)},
            {'score': 0.5, 'show': null},
            'x',
            {'score': 0.4, 'show': showJson(8)},
          ],
      '/shows/5': (_) => showJson(5),
      '/shows/6': (_) => 'not a map',
      '/shows/7': (_) => throw const ApiException('Server error (500).', statusCode: 500),
      '/shows/5/cast': (_) => [
            {
              'person': {'id': 1, 'name': 'A'},
              'character': {'name': 'C'},
            },
            42,
          ],
      '/shows/5/episodes': (_) => [
            {'id': 1, 'name': 'b', 'season': 2, 'number': 1},
            {'id': 2, 'name': 'a', 'season': 1, 'number': 1},
            {'id': 3, 'name': 'c', 'season': 2, 'number': 2},
            {'id': 4, 'name': 'sp', 'season': 1, 'number': null},
          ],
      '/shows/404/cast': (_) => throw _notFound,
      '/shows/404/episodes': (_) => throw _notFound,
    });
    repo = ShowRepository(ShowApiService(client));
  });

  test('page is requested by number, malformed entries skipped, popular first',
      () async {
    final shows = await repo.getShows(page: 0);
    expect(client.calls.single, '/shows {page: 0}');
    expect(shows.map((s) => s.id), [2, 3, 1]);
  });

  test('a page past the end (404) means "no more shows"', () async {
    expect(await repo.getShows(page: 99), isEmpty);
  });

  test('search unwraps {show}, skips bad hits and keeps API order', () async {
    final results = await repo.searchShows('x');
    expect(client.calls.single, '/search/shows {q: x}');
    expect(results.map((s) => s.id), [7, 8]);
  });

  test('details: unexpected body and server errors surface as ApiException',
      () async {
    expect((await repo.getShowDetails(5)).id, 5);
    expect(
      repo.getShowDetails(6),
      throwsA(isA<ApiException>()
          .having((e) => e.message, 'message', 'Unexpected response from the server.')),
    );
    expect(
      repo.getShowDetails(7),
      throwsA(isA<ApiException>().having((e) => e.statusCode, 'statusCode', 500)),
    );
  });

  test('cast skips bad entries; 404 means empty', () async {
    expect(await repo.getCast(5), hasLength(1));
    expect(await repo.getCast(404), isEmpty);
  });

  test('episodes are grouped by season in ascending order', () async {
    final seasons = await repo.getEpisodesBySeason(5);
    expect(seasons.keys.toList(), [1, 2]);
    expect(seasons[1]!.map((e) => e.id), [2, 4]); // incl. the special
    expect(seasons[2]!.map((e) => e.id), [1, 3]);
    expect(await repo.getEpisodesBySeason(404), isEmpty);
  });
}
