import 'package:tvmaze_app/core/network/api_client.dart';

typedef RouteHandler = dynamic Function(Map<String, dynamic>? query);

/// Replays canned responses by path, so tests never touch the network.
/// A handler may throw an `ApiException` to simulate a failed request.
class FakeApiClient extends ApiClient {
  FakeApiClient(this.routes);

  final Map<String, RouteHandler> routes;

  /// Every request made, as "path {query}".
  final List<String> calls = [];

  @override
  Future<dynamic> get(
    String path, {
    Map<String, dynamic>? queryParameters,
  }) async {
    calls.add('$path ${queryParameters ?? ''}'.trim());
    final handler = routes[path];
    if (handler == null) throw StateError('No fake route for $path');
    return handler(queryParameters);
  }
}

Map<String, dynamic> showJson(
  int id, {
  String? name,
  int weight = 0,
  double? rating,
}) =>
    {
      'id': id,
      'name': name ?? 'Show $id',
      'weight': weight,
      'rating': {'average': rating},
      'image': {'medium': 'https://img.example/$id.jpg'},
    };
