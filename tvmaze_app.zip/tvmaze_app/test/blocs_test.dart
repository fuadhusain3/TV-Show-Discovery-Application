import 'package:flutter_test/flutter_test.dart';
import 'package:tvmaze_app/blocs/home/home_bloc.dart';
import 'package:tvmaze_app/blocs/search/search_bloc.dart';
import 'package:tvmaze_app/blocs/show_details/show_details_bloc.dart';
import 'package:tvmaze_app/core/network/api_exception.dart';
import 'package:tvmaze_app/models/show_model.dart';
import 'package:tvmaze_app/repositories/show_repository.dart';
import 'package:tvmaze_app/services/show_api_service.dart';

import 'helpers/fake_api_client.dart';

ShowRepository _repo(FakeApiClient client) =>
    ShowRepository(ShowApiService(client));

const _timeout = Duration(seconds: 5);

void main() {
  group('HomeBloc', () {
    FakeApiClient pagedClient() => FakeApiClient({
          '/shows': (q) {
            final page = q!['page'] as int;
            if (page == 0) {
              return [
                showJson(1, weight: 5, rating: 7),
                showJson(2, weight: 9, rating: 9),
              ];
            }
            if (page == 1) return [showJson(3, weight: 1)];
            throw const ApiException('Not found.', statusCode: 404);
          },
        });

    test('loads page 0, appends page 1, then stops at the end', () async {
      final bloc = HomeBloc(_repo(pagedClient()))..add(const HomeStarted());

      final first = await bloc.stream
          .firstWhere((s) => s.status == HomeStatus.success)
          .timeout(_timeout);
      expect(first.shows.map((s) => s.id), [2, 1]); // most popular first
      expect(first.trending.map((s) => s.id), [2, 1]); // best rated first
      expect(first.nextPage, 1);

      bloc.add(const HomeLoadMoreRequested());
      final second = await bloc.stream
          .firstWhere((s) => s.shows.length == 3 && !s.isLoadingMore)
          .timeout(_timeout);
      expect(second.shows.map((s) => s.id), [2, 1, 3]);
      expect(second.nextPage, 2);

      bloc.add(const HomeLoadMoreRequested());
      final end = await bloc.stream
          .firstWhere((s) => s.hasReachedMax)
          .timeout(_timeout);
      expect(end.shows, hasLength(3));
      await bloc.close();
    });

    test('a failed first load reports the message', () async {
      final bloc = HomeBloc(_repo(FakeApiClient({
        '/shows': (_) => throw const ApiException('No internet connection.'),
      })))
        ..add(const HomeStarted());

      final state = await bloc.stream
          .firstWhere((s) => s.status == HomeStatus.failure)
          .timeout(_timeout);
      expect(state.errorMessage, 'No internet connection.');
      await bloc.close();
    });

    test('a failed next page keeps the shows and sets loadMoreError', () async {
      var failNext = false;
      final bloc = HomeBloc(_repo(FakeApiClient({
        '/shows': (q) {
          if (q!['page'] == 0) return [showJson(1)];
          if (failNext) throw const ApiException('The request timed out.');
          return [showJson(2)];
        },
      })))
        ..add(const HomeStarted());
      await bloc.stream
          .firstWhere((s) => s.status == HomeStatus.success)
          .timeout(_timeout);

      failNext = true;
      bloc.add(const HomeLoadMoreRequested());
      final failed = await bloc.stream
          .firstWhere((s) => s.loadMoreError != null)
          .timeout(_timeout);
      expect(failed.shows.map((s) => s.id), [1]);
      expect(failed.isLoadingMore, isFalse);

      // Retry succeeds and clears the error.
      failNext = false;
      bloc.add(const HomeLoadMoreRequested());
      final ok = await bloc.stream
          .firstWhere((s) => s.shows.length == 2)
          .timeout(_timeout);
      expect(ok.loadMoreError, isNull);
      await bloc.close();
    });
  });

  group('SearchBloc', () {
    test('debounces typing and searches only the final text', () async {
      final client = FakeApiClient({
        '/search/shows': (_) => [
              {'score': 1, 'show': showJson(1)},
            ],
      });
      final bloc = SearchBloc(_repo(client))
        ..add(const SearchQueryChanged('a'))
        ..add(const SearchQueryChanged('ab'))
        ..add(const SearchQueryChanged('abc'));

      await Future<void>.delayed(
        SearchBloc.debounceDuration + const Duration(milliseconds: 400),
      );

      expect(client.calls, ['/search/shows {q: abc}']);
      expect(bloc.state.status, SearchStatus.success);
      expect(bloc.state.results.map((s) => s.id), [1]);
      await bloc.close();
    });

    test('clearing the field resets at once and cancels the pending search',
        () async {
      final client = FakeApiClient({'/search/shows': (_) => <dynamic>[]});
      final bloc = SearchBloc(_repo(client))
        ..add(const SearchQueryChanged('abc'))
        ..add(const SearchCleared());

      await Future<void>.delayed(
        SearchBloc.debounceDuration + const Duration(milliseconds: 400),
      );

      expect(client.calls, isEmpty);
      expect(bloc.state, const SearchState());
      await bloc.close();
    });

    test('no matches is an empty result; errors can be retried', () async {
      var fail = true;
      final client = FakeApiClient({
        '/search/shows': (_) {
          if (fail) throw const ApiException('No internet connection.');
          return <dynamic>[];
        },
      });
      final bloc = SearchBloc(_repo(client))
        ..add(const SearchQueryChanged('zzz'));

      final failed = await bloc.stream
          .firstWhere((s) => s.status == SearchStatus.failure)
          .timeout(_timeout);
      expect(failed.errorMessage, 'No internet connection.');

      fail = false;
      bloc.add(const SearchRetried());
      final done = await bloc.stream
          .firstWhere((s) => s.status == SearchStatus.success)
          .timeout(_timeout);
      expect(done.isEmptyResult, isTrue);
      await bloc.close();
    });
  });

  group('ShowDetailsBloc', () {
    test('shows the list item instantly, then loads details, cast, seasons',
        () async {
      final client = FakeApiClient({
        '/shows/5': (_) => showJson(5, name: 'Fresh name'),
        '/shows/5/cast': (_) => [
              {
                'person': {'id': 1, 'name': 'A'},
                'character': {'name': 'C'},
              },
            ],
        '/shows/5/episodes': (_) => [
              {'id': 1, 'name': 'e', 'season': 2, 'number': 1},
              {'id': 2, 'name': 'e', 'season': 1, 'number': 1},
            ],
      });
      final bloc = ShowDetailsBloc(_repo(client))
        ..add(const ShowDetailsStarted(
          5,
          initialShow: ShowModel(id: 5, name: 'From list'),
        ));

      final state = await bloc.stream
          .firstWhere((s) =>
              s.show?.name == 'Fresh name' &&
              s.castStatus == LoadStatus.success &&
              s.episodesStatus == LoadStatus.success)
          .timeout(_timeout);

      expect(state.cast, hasLength(1));
      expect(state.seasonCount, 2);
      expect(state.selectedSeason, 1);
      expect(state.selectedEpisodes.map((e) => e.id), [2]);
      await bloc.close();
    });

    test('a failing section does not hide the others; season can change',
        () async {
      final client = FakeApiClient({
        '/shows/5': (_) => showJson(5),
        '/shows/5/cast': (_) => throw const ApiException('Server error (500).'),
        '/shows/5/episodes': (_) => [
              {'id': 1, 'name': 'e', 'season': 1, 'number': 1},
              {'id': 2, 'name': 'e', 'season': 2, 'number': 1},
            ],
      });
      final bloc = ShowDetailsBloc(_repo(client))
        ..add(const ShowDetailsStarted(5));

      final state = await bloc.stream
          .firstWhere((s) =>
              s.castStatus == LoadStatus.failure &&
              s.episodesStatus == LoadStatus.success &&
              s.detailsStatus == LoadStatus.success)
          .timeout(_timeout);
      expect(state.castError, 'Server error (500).');
      expect(state.show, isNotNull);

      bloc.add(const ShowDetailsSeasonSelected(2));
      final switched = await bloc.stream
          .firstWhere((s) => s.selectedSeason == 2)
          .timeout(_timeout);
      expect(switched.selectedEpisodes.map((e) => e.id), [2]);
      await bloc.close();
    });
  });
}
