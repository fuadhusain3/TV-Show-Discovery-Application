import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tvmaze_app/blocs/watchlist/watchlist_bloc.dart';
import 'package:tvmaze_app/models/show_model.dart';
import 'package:tvmaze_app/repositories/watchlist_repository.dart';
import 'package:tvmaze_app/services/watchlist_local_service.dart';

const _a = ShowModel(
  id: 1,
  name: 'Show A',
  genres: ['Drama', 'Crime'],
  rating: 8.5,
  imageMediumUrl: 'https://example.com/a.jpg',
  premiered: '2008-01-20',
  network: 'AMC',
);
const _b = ShowModel(id: 2, name: 'Show B');

Future<WatchlistRepository> _repo() async {
  final prefs = await SharedPreferences.getInstance();
  return WatchlistRepository(WatchlistLocalService(prefs));
}

Future<WatchlistBloc> _loadedBloc() async {
  final bloc = WatchlistBloc(await _repo())..add(const WatchlistStarted());
  await bloc.stream.firstWhere((s) => s.status == WatchlistStatus.success);
  return bloc;
}

/// Lets queued events finish.
Future<void> _settle() => Future<void>.delayed(const Duration(milliseconds: 50));

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));

  group('ShowModel JSON round trip', () {
    test('keeps every field', () {
      expect(ShowModel.fromJson(_a.toJson()), _a);
    });

    test('works for a show with only id and name', () {
      expect(ShowModel.fromJson(_b.toJson()), _b);
    });
  });

  group('WatchlistRepository', () {
    test('adds newest first and ignores duplicates', () async {
      final repo = await _repo();
      await repo.add(_a);
      await repo.add(_b);
      final afterDuplicate = await repo.add(_a);

      expect(afterDuplicate.map((s) => s.id), [2, 1]);
    });

    test('removes a show and ignores unknown ids', () async {
      final repo = await _repo();
      await repo.add(_a);
      await repo.add(_b);

      expect((await repo.remove(1)).map((s) => s.id), [2]);
      expect((await repo.remove(99)).map((s) => s.id), [2]);
    });

    test('data survives an app restart', () async {
      await (await _repo()).add(_a);

      // A new repository over the same stored data simulates a restart.
      final restored = await (await _repo()).getWatchlist();
      expect(restored, [_a]);
    });

    test('skips corrupt entries and collapses stored duplicates', () async {
      final good = WatchlistLocalService(await SharedPreferences.getInstance());
      await good.write([_a, _b]);
      final prefs = await SharedPreferences.getInstance();
      final stored = prefs.getStringList('watchlist_v1')!;
      await prefs.setStringList(
        'watchlist_v1',
        ['not json', ...stored, stored.first],
      );

      final shows = await WatchlistLocalService(prefs).read();
      expect(shows.map((s) => s.id), [1, 2]);
    });
  });

  group('WatchlistBloc', () {
    test('loads the saved list on start', () async {
      await (await _repo()).add(_a);

      final bloc = await _loadedBloc();
      expect(bloc.state.shows, [_a]);
      expect(bloc.state.contains(1), isTrue);
      await bloc.close();
    });

    test('toggle adds then removes', () async {
      final bloc = await _loadedBloc();

      bloc.add(const WatchlistToggled(_a));
      await _settle();
      expect(bloc.state.shows, [_a]);

      bloc.add(const WatchlistToggled(_a));
      await _settle();
      expect(bloc.state.shows, isEmpty);
      await bloc.close();
    });

    test('rapid taps and repeated adds never create duplicates', () async {
      final bloc = await _loadedBloc();

      bloc
        ..add(const WatchlistShowAdded(_a))
        ..add(const WatchlistShowAdded(_a))
        ..add(const WatchlistShowAdded(_b))
        ..add(const WatchlistShowAdded(_a));
      await _settle();

      expect(bloc.state.shows.map((s) => s.id), [2, 1]);
      await bloc.close();
    });

    test('mixed event types do not lose updates', () async {
      final bloc = await _loadedBloc();

      bloc
        ..add(const WatchlistToggled(_a))
        ..add(const WatchlistShowAdded(_b))
        ..add(const WatchlistShowRemoved(1));
      await _settle();

      expect(bloc.state.shows.map((s) => s.id), [2]);
      expect((await (await _repo()).getWatchlist()).map((s) => s.id), [2]);
      await bloc.close();
    });

    test('clear empties the list', () async {
      final bloc = await _loadedBloc();
      bloc
        ..add(const WatchlistShowAdded(_a))
        ..add(const WatchlistShowAdded(_b))
        ..add(const WatchlistCleared());
      await _settle();

      expect(bloc.state.shows, isEmpty);
      expect(await (await _repo()).getWatchlist(), isEmpty);
      await bloc.close();
    });
  });
}
