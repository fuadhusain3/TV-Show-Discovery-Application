import 'package:flutter_test/flutter_test.dart';
import 'package:tvmaze_app/core/utils/date_formatter.dart';
import 'package:tvmaze_app/core/utils/html_utils.dart';
import 'package:tvmaze_app/models/cast_member_model.dart';
import 'package:tvmaze_app/models/episode_model.dart';
import 'package:tvmaze_app/models/show_model.dart';

void main() {
  group('ShowModel.fromJson', () {
    test('parses a full TVMaze payload', () {
      final show = ShowModel.fromJson({
        'id': 169,
        'name': 'Sample Show',
        'language': 'English',
        'genres': ['Drama', 'Crime', 'Thriller'],
        'status': 'Ended',
        'premiered': '2008-01-20',
        'ended': '2013-09-29',
        'rating': {'average': 9.3},
        'weight': 98,
        'network': {'id': 20, 'name': 'AMC'},
        'image': {
          'medium': 'http://static.tvmaze.com/m.jpg',
          'original': 'http://static.tvmaze.com/o.jpg',
        },
        'summary': '<p>A <b>teacher</b> turns to crime &amp; it&#39;s risky.</p>',
      });

      expect(show.posterUrl, 'https://static.tvmaze.com/m.jpg'); // https
      expect(show.imageOriginalUrl, 'https://static.tvmaze.com/o.jpg');
      expect(show.network, 'AMC');
      expect(show.genresLabel, 'Drama, Crime');
      expect(show.yearsLabel, '2008 - 2013');
      expect(show.plainSummary, "A teacher turns to crime & it's risky.");
    });

    test('survives null and missing fields', () {
      final show = ShowModel.fromJson({
        'id': 5,
        'name': '  ',
        'genres': null,
        'rating': {'average': null},
        'image': null,
        'network': null,
        'webChannel': {'name': 'Netflix'},
        'summary': null,
        'weight': null,
      });

      expect(show.name, 'Untitled');
      expect(show.rating, isNull);
      expect(show.posterUrl, isNull);
      expect(show.network, 'Netflix'); // web channel fallback
      expect(show.genresLabel, isNull);
      expect(show.yearsLabel, isNull);
      expect(show.plainSummary, isNull);
    });

    test('a running show reads "Present"; an integer rating is accepted', () {
      final show = ShowModel.fromJson({
        'id': 1,
        'name': 'X',
        'premiered': '2023-05-01',
        'status': 'Running',
        'rating': {'average': 8},
      });
      expect(show.yearsLabel, '2023 - Present');
      expect(show.rating, 8.0);
    });
  });

  group('EpisodeModel / CastMemberModel', () {
    test('episode with image, rating and summary', () {
      final e = EpisodeModel.fromJson({
        'id': 10,
        'name': 'Pilot',
        'season': 1,
        'number': 1,
        'airdate': '2008-01-20',
        'runtime': 58,
        'rating': {'average': 8.2},
        'image': {'medium': 'http://x/e.jpg'},
        'summary': '<p>Hi.</p>',
      });
      expect(e.code, 'S1 · E1');
      expect(e.imageUrl, 'https://x/e.jpg');
      expect(e.plainSummary, 'Hi.');
    });

    test('special episode has no number and empty fields become null', () {
      final e = EpisodeModel.fromJson({
        'id': 11,
        'name': 'Recap',
        'season': 2,
        'number': null,
        'airdate': '',
        'runtime': null,
        'rating': {'average': null},
        'image': null,
        'summary': null,
      });
      expect(e.code, 'S2 · Special');
      expect(e.airdate, isNull);
    });

    test('cast falls back to character artwork and drops empty names', () {
      final withFallback = CastMemberModel.fromJson({
        'person': {'id': 7, 'name': 'Actor One', 'image': null},
        'character': {
          'name': 'Hero',
          'image': {'medium': 'http://c/h.jpg'},
        },
      });
      expect(withFallback.imageUrl, 'https://c/h.jpg');

      final noCharacter = CastMemberModel.fromJson({
        'person': {'id': 1, 'name': 'A'},
        'character': {'name': ''},
      });
      expect(noCharacter.characterName, isNull);
    });
  });

  group('utils', () {
    test('stripHtml removes tags and decodes entities', () {
      expect(
        stripHtml('<p>Tom &amp; Jerry &ndash; &quot;hi&quot;</p><p>Two</p>'),
        'Tom & Jerry \u2013 "hi"\n\nTwo',
      );
      expect(stripHtml(null), '');
    });

    test('formatAirdate', () {
      expect(formatAirdate('2008-01-20'), 'Jan 20, 2008');
      expect(formatAirdate('nope'), isNull);
      expect(formatAirdate(null), isNull);
    });
  });
}
