import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tvmaze_app/blocs/watchlist/watchlist_bloc.dart';
import 'package:tvmaze_app/models/show_model.dart';
import 'package:tvmaze_app/repositories/watchlist_repository.dart';
import 'package:tvmaze_app/screens/watchlist/watchlist_screen.dart';
import 'package:tvmaze_app/services/watchlist_local_service.dart';

const _a = ShowModel(id: 1, name: 'Show A', genres: ['Drama']);
const _b = ShowModel(id: 2, name: 'Show B');

Future<void> _pumpWatchlist(
  WidgetTester tester, {
  List<ShowModel> saved = const [],
}) async {
  SharedPreferences.setMockInitialValues({});
  final prefs = await SharedPreferences.getInstance();
  final service = WatchlistLocalService(prefs);
  await service.write(saved);

  final bloc = WatchlistBloc(WatchlistRepository(service))
    ..add(const WatchlistStarted());
  addTearDown(bloc.close);

  await tester.pumpWidget(
    MaterialApp(
      theme: ThemeData.dark(),
      home: BlocProvider.value(value: bloc, child: const WatchlistScreen()),
    ),
  );
  await tester.pumpAndSettle();
}

void main() {
  testWidgets('empty watchlist shows the empty state', (tester) async {
    await _pumpWatchlist(tester);

    expect(find.text('My Watchlist'), findsOneWidget);
    expect(find.text('Your watchlist is empty'), findsOneWidget);
    expect(find.text('Explore Shows'), findsOneWidget);
    expect(find.byTooltip('Clear watchlist'), findsNothing);
  });

  testWidgets('saved shows are listed with titles and a count', (tester) async {
    await _pumpWatchlist(tester, saved: [_a, _b]);

    expect(find.text('Show A'), findsOneWidget);
    expect(find.text('Show B'), findsOneWidget);
    expect(find.text('2 shows saved'), findsOneWidget);
    expect(find.text('Your watchlist is empty'), findsNothing);
  });

  testWidgets('tapping the heart removes a show', (tester) async {
    await _pumpWatchlist(tester, saved: [_a, _b]);

    await tester.tap(find.byTooltip('Remove from watchlist').first);
    await tester.pumpAndSettle();

    expect(find.text('Show A'), findsNothing);
    expect(find.text('Show B'), findsOneWidget);
    expect(find.text('1 show saved'), findsOneWidget);

    // Dispose the tree so the snackbar timer is cancelled.
    await tester.pumpWidget(const SizedBox());
  });
}
