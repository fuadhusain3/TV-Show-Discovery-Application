import 'package:get_it/get_it.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../blocs/home/home_bloc.dart';
import '../../blocs/search/search_bloc.dart';
import '../../blocs/show_details/show_details_bloc.dart';
import '../../blocs/watchlist/watchlist_bloc.dart';
import '../../repositories/show_repository.dart';
import '../../repositories/watchlist_repository.dart';
import '../../services/show_api_service.dart';
import '../../services/watchlist_local_service.dart';
import '../network/api_client.dart';

final GetIt sl = GetIt.instance;

/// Registers every dependency once at start-up.
/// Layers are wired bottom-up: ApiClient -> services -> repositories -> BLoCs.
Future<void> configureDependencies() async {
  // External
  final prefs = await SharedPreferences.getInstance();
  sl.registerSingleton<SharedPreferences>(prefs);

  // Core
  sl.registerLazySingleton<ApiClient>(ApiClient.new);

  // Services
  sl.registerLazySingleton<ShowApiService>(() => ShowApiService(sl()));
  sl.registerLazySingleton<WatchlistLocalService>(
    () => WatchlistLocalService(sl()),
  );

  // Repositories
  sl.registerLazySingleton<ShowRepository>(() => ShowRepository(sl()));
  sl.registerLazySingleton<WatchlistRepository>(
    () => WatchlistRepository(sl()),
  );

  // BLoCs (factories: each screen gets its own instance)
  sl.registerFactory<HomeBloc>(() => HomeBloc(sl()));
  sl.registerFactory<SearchBloc>(() => SearchBloc(sl()));
  sl.registerFactory<ShowDetailsBloc>(() => ShowDetailsBloc(sl()));
  sl.registerFactory<WatchlistBloc>(() => WatchlistBloc(sl()));
}
