/// Small null-safe helpers for parsing TVMaze JSON.
Map<String, dynamic>? asMap(Object? value) =>
    value is Map<String, dynamic> ? value : null;

String? nonEmptyString(Object? value) =>
    (value is String && value.trim().isNotEmpty) ? value.trim() : null;

/// TVMaze sometimes returns `http://` image links; upgrade them to https.
String? secureUrl(Object? value) =>
    nonEmptyString(value)?.replaceFirst('http://', 'https://');
