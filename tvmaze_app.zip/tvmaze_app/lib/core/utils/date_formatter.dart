const List<String> _months = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
];

/// "2008-01-20" -> "Jan 20, 2008". Returns `null` for missing/invalid dates.
String? formatAirdate(String? iso) {
  final date = iso == null ? null : DateTime.tryParse(iso);
  if (date == null) return null;
  return '${_months[date.month - 1]} ${date.day}, ${date.year}';
}
