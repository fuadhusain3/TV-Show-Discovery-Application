/// Converts the HTML snippets TVMaze returns for summaries into plain text.
String stripHtml(String? html) {
  if (html == null || html.isEmpty) return '';

  var text = html
      .replaceAll(RegExp(r'<br\s*/?>', caseSensitive: false), '\n')
      .replaceAll(RegExp(r'</p\s*>', caseSensitive: false), '\n\n')
      .replaceAll(RegExp(r'<[^>]*>'), '');

  text = _decodeEntities(text);

  return text
      .replaceAll(RegExp(r'[ \t]+'), ' ')
      .replaceAll(RegExp(r' ?\n ?'), '\n')
      .replaceAll(RegExp(r'\n{3,}'), '\n\n')
      .trim();
}

const Map<String, String> _namedEntities = {
  'amp': '&',
  'lt': '<',
  'gt': '>',
  'quot': '"',
  'apos': "'",
  'nbsp': ' ',
  'rsquo': '\u2019',
  'lsquo': '\u2018',
  'rdquo': '\u201D',
  'ldquo': '\u201C',
  'ndash': '\u2013',
  'mdash': '\u2014',
  'hellip': '\u2026',
};

String _decodeEntities(String input) {
  // Numeric entities: &#39; and &#x27;
  var out = input.replaceAllMapped(
    RegExp(r'&#(x?)([0-9a-fA-F]+);'),
    (m) {
      final code = int.tryParse(m[2]!, radix: m[1]!.isEmpty ? 10 : 16);
      if (code == null || code <= 0 || code > 0x10FFFF) return m[0]!;
      return String.fromCharCode(code);
    },
  );

  // Named entities
  out = out.replaceAllMapped(
    RegExp(r'&([a-zA-Z]+);'),
    (m) => _namedEntities[m[1]!.toLowerCase()] ?? m[0]!,
  );
  return out;
}
