import 'package:dio/dio.dart';

import '../constants/api_constants.dart';
import 'api_exception.dart';

/// Thin wrapper around Dio. API services use this; widgets never touch it.
class ApiClient {
  ApiClient()
      : _dio = Dio(
          BaseOptions(
            baseUrl: ApiConstants.baseUrl,
            connectTimeout: ApiConstants.connectTimeout,
            receiveTimeout: ApiConstants.receiveTimeout,
            headers: {'Accept': 'application/json'},
          ),
        );

  final Dio _dio;

  /// Returns the decoded JSON body (a `List` or a `Map`).
  Future<dynamic> get(
    String path, {
    Map<String, dynamic>? queryParameters,
  }) async {
    try {
      final response = await _dio.get<dynamic>(
        path,
        queryParameters: queryParameters,
      );
      return response.data;
    } on DioException catch (e) {
      throw _mapError(e);
    }
  }

  ApiException _mapError(DioException e) {
    switch (e.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        return const ApiException('The request timed out. Please try again.');
      case DioExceptionType.connectionError:
        return const ApiException('No internet connection.');
      case DioExceptionType.badResponse:
        final code = e.response?.statusCode;
        if (code == 404) {
          return ApiException('Not found.', statusCode: code);
        }
        if (code == 429) {
          return ApiException(
            'Too many requests. Please wait a moment.',
            statusCode: code,
          );
        }
        return ApiException('Server error ($code).', statusCode: code);
      default:
        return const ApiException('Something went wrong.');
    }
  }
}
