/// A simple, UI-friendly error type. Repositories and BLoCs only ever see this,
/// never a raw Dio exception.
class ApiException implements Exception {
  const ApiException(this.message, {this.statusCode});

  final String message;
  final int? statusCode;

  @override
  String toString() => 'ApiException($statusCode): $message';
}
