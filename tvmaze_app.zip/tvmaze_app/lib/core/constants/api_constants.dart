/// All TVMaze endpoints live here so no URL is ever written in a widget.
class ApiConstants {
  ApiConstants._();

  static const String baseUrl = 'https://api.tvmaze.com';

  static const Duration connectTimeout = Duration(seconds: 15);
  static const Duration receiveTimeout = Duration(seconds: 20);

  /// GET /shows?page={page}
  static const String shows = '/shows';

  /// GET /search/shows?q={query}
  static const String searchShows = '/search/shows';

  /// GET /search/people?q={query}
  static const String searchPeople = '/search/people';

  /// GET /shows/{id}
  static String showDetails(int id) => '/shows/$id';

  /// GET /shows/{id}/cast
  static String showCast(int id) => '/shows/$id/cast';

  /// GET /shows/{id}/episodes
  static String showEpisodes(int id) => '/shows/$id/episodes';
}
