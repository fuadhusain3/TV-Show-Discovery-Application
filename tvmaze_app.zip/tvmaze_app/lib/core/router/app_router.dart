import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../models/show_model.dart';
import '../../screens/home/home_screen.dart';
import '../../screens/not_found/not_found_screen.dart';
import '../../screens/profile/profile_screen.dart';
import '../../screens/search/search_screen.dart';
import '../../screens/shell/main_shell.dart';
import '../../screens/show_details/show_details_screen.dart';
import '../../screens/watchlist/watchlist_screen.dart';
import 'app_routes.dart';

class AppRouter {
  AppRouter._();

  static final GlobalKey<NavigatorState> _rootKey =
      GlobalKey<NavigatorState>(debugLabel: 'root');

  static final GoRouter router = GoRouter(
    navigatorKey: _rootKey,
    initialLocation: AppRoutes.home,
    errorBuilder: (context, state) => const NotFoundScreen(),
    routes: [
      // Bottom-navigation tabs (each keeps its own state).
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) =>
            MainShell(navigationShell: navigationShell),
        branches: [
          StatefulShellBranch(routes: [
            GoRoute(
              path: AppRoutes.home,
              builder: (context, state) => const HomeScreen(),
            ),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
              path: AppRoutes.search,
              builder: (context, state) => const SearchScreen(),
            ),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
              path: AppRoutes.watchlist,
              builder: (context, state) => const WatchlistScreen(),
            ),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
              path: AppRoutes.profile,
              builder: (context, state) => const ProfileScreen(),
            ),
          ]),
        ],
      ),

      // Full-screen details page (covers the bottom bar, like the design).
      GoRoute(
        parentNavigatorKey: _rootKey,
        name: AppRoutes.showDetailsName,
        path: AppRoutes.showDetailsPath,
        builder: (context, state) {
          final id = int.tryParse(state.pathParameters['id'] ?? '');
          if (id == null) return const NotFoundScreen();
          final extra = state.extra;
          return ShowDetailsScreen(
            showId: id,
            initialShow: extra is ShowModel ? extra : null,
          );
        },
      ),
    ],
  );
}
