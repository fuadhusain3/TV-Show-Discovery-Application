/// Route paths and names in one place.
class AppRoutes {
  AppRoutes._();

  static const String home = '/home';
  static const String search = '/search';
  static const String watchlist = '/watchlist';
  static const String profile = '/profile';

  static const String showDetailsName = 'show-details';
  static const String showDetailsPath = '/show/:id';

  static String showDetails(int id) => '/show/$id';
}
