import 'package:flutter/material.dart';

/// Colour palette taken from the design reference (dark UI, purple accent).
class AppColors {
  AppColors._();

  static const Color background = Color(0xFF0B0B12);
  static const Color surface = Color(0xFF16161F);
  static const Color surfaceLight = Color(0xFF20202C);
  static const Color border = Color(0xFF2A2A38);

  static const Color primary = Color(0xFF7C5CFF);
  static const Color primaryDark = Color(0xFF5B3FD6);

  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFFA0A0B2);
  static const Color textMuted = Color(0xFF6B6B7E);

  static const Color rating = Color(0xFFFFC107);
  static const Color favorite = Color(0xFFFF4D6D);
  static const Color error = Color(0xFFFF5C5C);
}
