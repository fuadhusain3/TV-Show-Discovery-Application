import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'blocs/watchlist/watchlist_bloc.dart';
import 'core/di/injector.dart';
import 'core/router/app_router.dart';
import 'core/theme/app_theme.dart';

class TvMazeApp extends StatelessWidget {
  const TvMazeApp({super.key});

  static final GlobalKey<ScaffoldMessengerState> _messengerKey =
      GlobalKey<ScaffoldMessengerState>();

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        // App-wide: heart buttons and the Watchlist tab share one instance,
        // loaded from device storage at start-up.
        BlocProvider<WatchlistBloc>(
          create: (_) => sl<WatchlistBloc>()..add(const WatchlistStarted()),
        ),
      ],
      child: BlocListener<WatchlistBloc, WatchlistState>(
        listenWhen: (previous, current) =>
            current.failureCount != previous.failureCount,
        listener: (context, state) {
          _messengerKey.currentState
            ?..hideCurrentSnackBar()
            ..showSnackBar(
              SnackBar(
                content: Text(state.errorMessage ?? 'Something went wrong.'),
              ),
            );
        },
        child: MaterialApp.router(
          title: 'TVMaze',
          debugShowCheckedModeBanner: false,
          scaffoldMessengerKey: _messengerKey,
          theme: AppTheme.dark,
          darkTheme: AppTheme.dark,
          themeMode: ThemeMode.dark,
          routerConfig: AppRouter.router,
        ),
      ),
    );
  }
}
