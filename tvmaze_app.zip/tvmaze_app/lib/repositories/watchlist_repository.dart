import '../models/show_model.dart';
import '../services/watchlist_local_service.dart';

/// Watchlist operations. Each change returns the updated list, newest first,
/// and a show can only appear once.
class WatchlistRepository {
  WatchlistRepository(this._storage);

  final WatchlistLocalService _storage;

  Future<List<ShowModel>> getWatchlist() => _storage.read();

  Future<List<ShowModel>> add(ShowModel show) async {
    final current = await _storage.read();
    if (current.any((s) => s.id == show.id)) return current; // no duplicates

    final updated = [show, ...current];
    await _storage.write(updated);
    return updated;
  }

  Future<List<ShowModel>> remove(int showId) async {
    final current = await _storage.read();
    final updated = current.where((s) => s.id != showId).toList();
    if (updated.length != current.length) await _storage.write(updated);
    return updated;
  }

  Future<List<ShowModel>> clear() async {
    await _storage.write(const []);
    return const [];
  }
}
