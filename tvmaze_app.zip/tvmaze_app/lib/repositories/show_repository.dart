import '../models/cast_member_model.dart';
import '../models/episode_model.dart';
import '../models/show_model.dart';
import '../services/show_api_service.dart';

/// Single source of shows for the BLoCs.
class ShowRepository {
  ShowRepository(this._service);

  final ShowApiService _service;

  /// One page of shows, most popular first.
  ///
  /// TVMaze lists shows by id, so each page is ordered by its popularity
  /// `weight` to surface well-known shows first.
  Future<List<ShowModel>> getShows({required int page}) async {
    final shows = await _service.getShows(page: page);
    return [...shows]..sort((a, b) => b.weight.compareTo(a.weight));
  }

  /// Shows matching [query], best match first.
  Future<List<ShowModel>> searchShows(String query) =>
      _service.searchShows(query);

  /// Full details for one show.
  Future<ShowModel> getShowDetails(int id) => _service.getShowDetails(id);

  /// Cast list for one show.
  Future<List<CastMemberModel>> getCast(int id) => _service.getShowCast(id);

  /// Episodes grouped by season number, seasons in ascending order.
  Future<Map<int, List<EpisodeModel>>> getEpisodesBySeason(int id) async {
    final episodes = await _service.getShowEpisodes(id);

    final bySeason = <int, List<EpisodeModel>>{};
    for (final episode in episodes) {
      bySeason.putIfAbsent(episode.season, () => []).add(episode);
    }

    final seasons = bySeason.keys.toList()..sort();
    return {for (final season in seasons) season: bySeason[season]!};
  }
}
