import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../blocs/home/home_bloc.dart';
import '../../core/di/injector.dart';
import '../../core/router/app_routes.dart';
import '../../core/theme/app_colors.dart';
import '../../widgets/error_view.dart';
import '../../widgets/section_header.dart';
import '../../widgets/show_card.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => sl<HomeBloc>()..add(const HomeStarted()),
      child: const _HomeView(),
    );
  }
}

class _HomeView extends StatefulWidget {
  const _HomeView();

  @override
  State<_HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<_HomeView> {
  final ScrollController _controller = ScrollController();

  /// Start loading the next page this far before the end of the list.
  static const double _loadMoreThreshold = 600;

  @override
  void initState() {
    super.initState();
    _controller.addListener(_onScroll);
  }

  @override
  void dispose() {
    _controller
      ..removeListener(_onScroll)
      ..dispose();
    super.dispose();
  }

  void _onScroll() {
    if (!_controller.hasClients) return;
    final position = _controller.position;
    if (position.pixels < position.maxScrollExtent - _loadMoreThreshold) {
      return;
    }
    final bloc = context.read<HomeBloc>();
    // After a failed page, wait for the user to tap "Retry".
    if (bloc.state.loadMoreError == null) {
      bloc.add(const HomeLoadMoreRequested());
    }
  }

  Future<void> _onRefresh() async {
    final completer = Completer<bool>();
    context.read<HomeBloc>().add(HomeRefreshed(completer));
    final success = await completer.future;
    if (!success && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Couldn't refresh. Check your connection.")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: BlocBuilder<HomeBloc, HomeState>(
          builder: (context, state) {
            switch (state.status) {
              case HomeStatus.initial:
              case HomeStatus.loading:
                return const Center(child: CircularProgressIndicator());
              case HomeStatus.failure:
                return ErrorView(
                  message: state.errorMessage ?? 'Something went wrong.',
                  onRetry: () =>
                      context.read<HomeBloc>().add(const HomeStarted()),
                );
              case HomeStatus.success:
                if (state.shows.isEmpty) {
                  return ErrorView(
                    message: 'No shows available right now.',
                    onRetry: () =>
                        context.read<HomeBloc>().add(const HomeStarted()),
                  );
                }
                return RefreshIndicator(
                  color: AppColors.primary,
                  backgroundColor: AppColors.surface,
                  onRefresh: _onRefresh,
                  child: _HomeContent(state: state, controller: _controller),
                );
            }
          },
        ),
      ),
    );
  }
}

class _HomeContent extends StatelessWidget {
  const _HomeContent({required this.state, required this.controller});

  final HomeState state;
  final ScrollController controller;

  static const double _gridPadding = 20;
  static const double _gridSpacing = 14;

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.sizeOf(context).width;
    final trendingWidth = (screenWidth * 0.36).clamp(120.0, 180.0);
    final textArea = ShowCard.textAreaHeightOf(context);
    final trendingHeight = trendingWidth * 1.5 + textArea;

    return CustomScrollView(
      controller: controller,
      physics: const AlwaysScrollableScrollPhysics(),
      slivers: [
        const SliverToBoxAdapter(child: _Header()),
        const SliverToBoxAdapter(child: _SearchBar()),

        if (state.trending.isNotEmpty) ...[
          const SliverToBoxAdapter(child: SectionHeader(title: 'Trending Now')),
          SliverToBoxAdapter(
            child: SizedBox(
              height: trendingHeight,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemCount: state.trending.length,
                separatorBuilder: (_, __) => const SizedBox(width: 14),
                itemBuilder: (_, i) => SizedBox(
                  width: trendingWidth,
                  child: ShowCard(show: state.trending[i]),
                ),
              ),
            ),
          ),
        ],

        const SliverToBoxAdapter(child: SectionHeader(title: 'Popular Shows')),
        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: _gridPadding),
          sliver: SliverLayoutBuilder(
            builder: (context, constraints) {
              // Responsive columns: ~150px wide cards, 2 to 6 per row.
              final width = constraints.crossAxisExtent;
              final columns = (width / 150).floor().clamp(2, 6);
              final cardWidth =
                  (width - _gridSpacing * (columns - 1)) / columns;
              final cardHeight = cardWidth * 1.5 + textArea;

              return SliverGrid.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: columns,
                  crossAxisSpacing: _gridSpacing,
                  mainAxisSpacing: 18,
                  childAspectRatio: cardWidth / cardHeight,
                ),
                itemCount: state.shows.length,
                itemBuilder: (_, i) => ShowCard(show: state.shows[i]),
              );
            },
          ),
        ),

        SliverToBoxAdapter(child: _ListFooter(state: state)),
      ],
    );
  }
}

class _Header extends StatelessWidget {
  const _Header();

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Hello,',
                  style: textTheme.bodyMedium
                      ?.copyWith(color: AppColors.textSecondary),
                ),
                const SizedBox(height: 2),
                Text(
                  'TV Explorer! 👋',
                  style: textTheme.headlineSmall
                      ?.copyWith(fontWeight: FontWeight.w800),
                ),
              ],
            ),
          ),
          IconButton.filled(
            style: IconButton.styleFrom(
              backgroundColor: AppColors.surface,
              foregroundColor: AppColors.textPrimary,
            ),
            onPressed: () => context.go(AppRoutes.profile),
            icon: const Icon(Icons.settings_outlined, size: 20),
          ),
        ],
      ),
    );
  }
}

/// Looks like a text field but simply opens the Search tab.
class _SearchBar extends StatelessWidget {
  const _SearchBar();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => context.go(AppRoutes.search),
        child: Container(
          height: 48,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
          ),
          child: const Row(
            children: [
              Icon(Icons.search_rounded, color: AppColors.textMuted),
              SizedBox(width: 12),
              Text(
                'Search shows...',
                style: TextStyle(color: AppColors.textMuted),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Bottom of the grid: spinner, retry, or end-of-list message.
class _ListFooter extends StatelessWidget {
  const _ListFooter({required this.state});

  final HomeState state;

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.paddingOf(context).bottom;

    Widget child;
    if (state.loadMoreError != null) {
      child = Column(
        children: [
          Text(
            state.loadMoreError!,
            textAlign: TextAlign.center,
            style: const TextStyle(color: AppColors.textSecondary),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () =>
                context.read<HomeBloc>().add(const HomeLoadMoreRequested()),
            icon: const Icon(Icons.refresh_rounded),
            label: const Text('Retry'),
          ),
        ],
      );
    } else if (state.isLoadingMore) {
      child = const SizedBox(
        height: 28,
        width: 28,
        child: CircularProgressIndicator(strokeWidth: 3),
      );
    } else if (state.hasReachedMax) {
      child = const Text(
        "You've reached the end",
        style: TextStyle(color: AppColors.textMuted),
      );
    } else {
      child = const SizedBox(height: 28);
    }

    return Padding(
      padding: EdgeInsets.fromLTRB(20, 24, 20, 24 + bottomInset),
      child: Center(child: child),
    );
  }
}
