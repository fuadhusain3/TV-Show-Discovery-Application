import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../blocs/show_details/show_details_bloc.dart';
import '../../core/di/injector.dart';
import '../../core/theme/app_colors.dart';
import '../../models/show_model.dart';
import '../../widgets/error_view.dart';
import 'show_details_header.dart';
import 'tabs/cast_tab.dart';
import 'tabs/episodes_tab.dart';
import 'tabs/overview_tab.dart';

class ShowDetailsScreen extends StatelessWidget {
  const ShowDetailsScreen({super.key, required this.showId, this.initialShow});

  final int showId;

  /// The show as it appeared in the list, used to render instantly.
  final ShowModel? initialShow;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => sl<ShowDetailsBloc>()
        ..add(ShowDetailsStarted(showId, initialShow: initialShow)),
      child: DefaultTabController(
        length: 3,
        child: _DetailsView(showId: showId),
      ),
    );
  }
}

class _DetailsView extends StatelessWidget {
  const _DetailsView({required this.showId});

  final int showId;

  static const TabBar _tabBar = TabBar(
    indicatorColor: AppColors.primary,
    labelColor: AppColors.textPrimary,
    unselectedLabelColor: AppColors.textSecondary,
    dividerColor: AppColors.border,
    labelStyle: TextStyle(fontWeight: FontWeight.w600),
    tabs: [
      Tab(text: 'Overview'),
      Tab(text: 'Episodes'),
      Tab(text: 'Cast'),
    ],
  );

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ShowDetailsBloc, ShowDetailsState>(
      buildWhen: (p, c) =>
          p.show != c.show ||
          p.detailsStatus != c.detailsStatus ||
          p.seasonCount != c.seasonCount,
      builder: (context, state) {
        final show = state.show;

        // Nothing to show yet: loading or failed first fetch (deep link).
        if (show == null) {
          return Scaffold(
            appBar: AppBar(),
            body: state.detailsStatus == LoadStatus.failure
                ? ErrorView(
                    message: state.detailsError ?? 'Something went wrong.',
                    onRetry: () => context
                        .read<ShowDetailsBloc>()
                        .add(ShowDetailsStarted(showId)),
                  )
                : const Center(child: CircularProgressIndicator()),
          );
        }

        return Scaffold(
          body: SafeArea(
            bottom: false,
            child: NestedScrollView(
              headerSliverBuilder: (context, innerScrolled) => [
                SliverToBoxAdapter(
                  child: ShowDetailsHeader(
                    show: show,
                    seasonCount: state.seasonCount,
                  ),
                ),
                const SliverPersistentHeader(
                  pinned: true,
                  delegate: _TabBarDelegate(_tabBar),
                ),
              ],
              body: const TabBarView(
                children: [
                  OverviewTab(),
                  EpisodesTab(),
                  CastTab(),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _TabBarDelegate extends SliverPersistentHeaderDelegate {
  const _TabBarDelegate(this.tabBar);

  final TabBar tabBar;

  @override
  double get minExtent => tabBar.preferredSize.height;

  @override
  double get maxExtent => tabBar.preferredSize.height;

  @override
  Widget build(
    BuildContext context,
    double shrinkOffset,
    bool overlapsContent,
  ) {
    return ColoredBox(color: AppColors.background, child: tabBar);
  }

  @override
  bool shouldRebuild(covariant _TabBarDelegate oldDelegate) => false;
}
