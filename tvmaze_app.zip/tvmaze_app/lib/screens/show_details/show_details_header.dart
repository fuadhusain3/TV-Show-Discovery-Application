import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/router/app_routes.dart';
import '../../core/theme/app_colors.dart';
import '../../models/show_model.dart';
import '../../widgets/expandable_text.dart';
import '../../widgets/poster_image.dart';
import '../../widgets/watchlist_button.dart';

/// Hero poster with the title, then rating/years/seasons, genres and summary.
class ShowDetailsHeader extends StatelessWidget {
  const ShowDetailsHeader({
    super.key,
    required this.show,
    required this.seasonCount,
  });

  final ShowModel show;
  final int seasonCount;

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    final heroHeight =
        (MediaQuery.sizeOf(context).height * 0.36).clamp(240.0, 420.0);
    final summary = show.plainSummary;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // ---- Hero ----
        Stack(
          children: [
            SizedBox(
              height: heroHeight,
              width: double.infinity,
              child: PosterImage(
                url: show.imageOriginalUrl ?? show.imageMediumUrl,
                borderRadius: 0,
                alignment: Alignment.topCenter,
              ),
            ),
            const Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, AppColors.background],
                    stops: [0.45, 1.0],
                  ),
                ),
              ),
            ),
            Positioned(
              top: 12,
              left: 16,
              child: _CircleButton(
                icon: Icons.arrow_back_rounded,
                onTap: () => context.canPop()
                    ? context.pop()
                    : context.go(AppRoutes.home),
              ),
            ),
            Positioned(
              top: 12,
              right: 16,
              child: WatchlistHeartButton(show: show, iconSize: 22),
            ),
            Positioned(
              left: 20,
              right: 20,
              bottom: 4,
              child: Text(
                show.name,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: textTheme.headlineSmall
                    ?.copyWith(fontWeight: FontWeight.w800),
              ),
            ),
          ],
        ),

        Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _MetaRow(show: show, seasonCount: seasonCount),
              if (show.genres.isNotEmpty) ...[
                const SizedBox(height: 14),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final genre in show.genres) _GenreChip(label: genre),
                  ],
                ),
              ],
              const SizedBox(height: 16),
              if (summary != null)
                ExpandableText(
                  text: summary,
                  maxLines: 4,
                  style: textTheme.bodyMedium?.copyWith(
                    color: AppColors.textSecondary,
                    height: 1.5,
                  ),
                )
              else
                Text(
                  'No summary available.',
                  style: textTheme.bodyMedium
                      ?.copyWith(color: AppColors.textMuted),
                ),
              const SizedBox(height: 20),
              WatchlistToggleButton(show: show),
            ],
          ),
        ),
      ],
    );
  }
}

class _MetaRow extends StatelessWidget {
  const _MetaRow({required this.show, required this.seasonCount});

  final ShowModel show;
  final int seasonCount;

  @override
  Widget build(BuildContext context) {
    final style = Theme.of(context)
        .textTheme
        .bodySmall
        ?.copyWith(color: AppColors.textSecondary);
    final rating = show.rating;

    final items = <Widget>[
      if (show.yearsLabel != null) Text(show.yearsLabel!, style: style),
      if (seasonCount > 0)
        Text(
          '$seasonCount ${seasonCount == 1 ? 'Season' : 'Seasons'}',
          style: style,
        ),
      if (rating != null)
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.star_rounded, size: 16, color: AppColors.rating),
            const SizedBox(width: 3),
            Text(
              '${rating.toStringAsFixed(1)}/10',
              style: style?.copyWith(
                color: AppColors.textPrimary,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
    ];

    if (items.isEmpty) return const SizedBox.shrink();

    return Wrap(
      crossAxisAlignment: WrapCrossAlignment.center,
      spacing: 10,
      runSpacing: 6,
      children: [
        for (var i = 0; i < items.length; i++) ...[
          if (i > 0)
            const Icon(Icons.circle, size: 4, color: AppColors.textMuted),
          items[i],
        ],
      ],
    );
  }
}

class _GenreChip extends StatelessWidget {
  const _GenreChip({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
      ),
      child: Text(
        label,
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w500,
          color: AppColors.textSecondary,
        ),
      ),
    );
  }
}

class _CircleButton extends StatelessWidget {
  const _CircleButton({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0x99000000),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Icon(icon, size: 22, color: Colors.white),
        ),
      ),
    );
  }
}
