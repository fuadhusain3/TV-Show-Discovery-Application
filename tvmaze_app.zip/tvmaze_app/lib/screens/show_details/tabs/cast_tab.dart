import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../blocs/show_details/show_details_bloc.dart';
import '../../../core/theme/app_colors.dart';
import '../../../models/cast_member_model.dart';
import '../../../widgets/error_view.dart';
import '../../../widgets/message_view.dart';
import '../../../widgets/poster_image.dart';

class CastTab extends StatelessWidget {
  const CastTab({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ShowDetailsBloc, ShowDetailsState>(
      buildWhen: (p, c) =>
          p.castStatus != c.castStatus || p.cast != c.cast,
      builder: (context, state) {
        switch (state.castStatus) {
          case LoadStatus.initial:
          case LoadStatus.loading:
            return const Center(child: CircularProgressIndicator());

          case LoadStatus.failure:
            return ErrorView(
              message: state.castError ?? 'Could not load the cast.',
              onRetry: () => context
                  .read<ShowDetailsBloc>()
                  .add(const ShowDetailsCastRetried()),
            );

          case LoadStatus.success:
            if (state.cast.isEmpty) {
              return const MessageView(
                icon: Icons.people_outline_rounded,
                title: 'No cast information',
                subtitle: 'The cast for this show has not been listed yet.',
              );
            }
            final bottomInset = MediaQuery.paddingOf(context).bottom;
            return ListView.separated(
              padding: EdgeInsets.fromLTRB(20, 8, 20, 16 + bottomInset),
              itemCount: state.cast.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) => _CastTile(member: state.cast[i]),
            );
        }
      },
    );
  }
}

class _CastTile extends StatelessWidget {
  const _CastTile({required this.member});

  final CastMemberModel member;

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          SizedBox(
            width: 52,
            height: 52,
            child: PosterImage(
              url: member.imageUrl,
              borderRadius: 26,
              alignment: Alignment.topCenter,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  member.personName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: textTheme.bodyLarge
                      ?.copyWith(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 2),
                Text(
                  member.characterName ?? 'Character unknown',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: textTheme.bodySmall
                      ?.copyWith(color: AppColors.textSecondary),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
