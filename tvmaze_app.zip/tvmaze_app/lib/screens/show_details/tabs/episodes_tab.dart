import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../blocs/show_details/show_details_bloc.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/utils/date_formatter.dart';
import '../../../models/episode_model.dart';
import '../../../widgets/error_view.dart';
import '../../../widgets/message_view.dart';
import '../../../widgets/poster_image.dart';

class EpisodesTab extends StatelessWidget {
  const EpisodesTab({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ShowDetailsBloc, ShowDetailsState>(
      builder: (context, state) {
        switch (state.episodesStatus) {
          case LoadStatus.initial:
          case LoadStatus.loading:
            return const Center(child: CircularProgressIndicator());

          case LoadStatus.failure:
            return ErrorView(
              message: state.episodesError ?? 'Could not load the episodes.',
              onRetry: () => context
                  .read<ShowDetailsBloc>()
                  .add(const ShowDetailsEpisodesRetried()),
            );

          case LoadStatus.success:
            if (state.seasons.isEmpty) {
              return const MessageView(
                icon: Icons.video_library_outlined,
                title: 'No episodes available',
                subtitle: 'Episodes for this show have not been listed yet.',
              );
            }
            return _EpisodesList(state: state);
        }
      },
    );
  }
}

class _EpisodesList extends StatelessWidget {
  const _EpisodesList({required this.state});

  final ShowDetailsState state;

  @override
  Widget build(BuildContext context) {
    final episodes = state.selectedEpisodes;
    final bottomInset = MediaQuery.paddingOf(context).bottom;

    return ListView.builder(
      padding: EdgeInsets.only(top: 16, bottom: 16 + bottomInset),
      itemCount: episodes.length + 1,
      itemBuilder: (context, index) {
        if (index == 0) return _SeasonSelector(state: state);
        final episode = episodes[index - 1];
        return _EpisodeTile(
          episode: episode,
          onTap: () => _showEpisodeSheet(context, episode),
        );
      },
    );
  }
}

class _SeasonSelector extends StatelessWidget {
  const _SeasonSelector({required this.state});

  final ShowDetailsState state;

  String _label(int season) {
    final count = state.seasons[season]?.length ?? 0;
    return 'Season $season ($count ${count == 1 ? 'episode' : 'episodes'})';
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border),
        ),
        child: DropdownButtonHideUnderline(
          child: DropdownButton<int>(
            value: state.selectedSeason,
            isExpanded: true,
            dropdownColor: AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            icon: const Icon(Icons.keyboard_arrow_down_rounded),
            items: [
              for (final season in state.seasons.keys)
                DropdownMenuItem(value: season, child: Text(_label(season))),
            ],
            onChanged: (season) {
              if (season != null) {
                context
                    .read<ShowDetailsBloc>()
                    .add(ShowDetailsSeasonSelected(season));
              }
            },
          ),
        ),
      ),
    );
  }
}

class _EpisodeTile extends StatelessWidget {
  const _EpisodeTile({required this.episode, required this.onTap});

  final EpisodeModel episode;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    final date = formatAirdate(episode.airdate);
    final details = [
      if (date != null) date,
      if (episode.runtime != null) '${episode.runtime} min',
    ].join(' · ');

    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        child: Row(
          children: [
            SizedBox(
              width: 104,
              height: 60,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  PosterImage(url: episode.imageUrl, borderRadius: 8),
                  Positioned(
                    left: 6,
                    bottom: 6,
                    child: Container(
                      constraints: const BoxConstraints(minWidth: 22),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: const Color(0xB3000000),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        episode.number?.toString() ?? '•',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    episode.name,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: textTheme.bodyMedium
                        ?.copyWith(fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    details.isEmpty ? 'Air date unknown' : details,
                    style: textTheme.bodySmall
                        ?.copyWith(color: AppColors.textSecondary),
                  ),
                ],
              ),
            ),
            if (episode.rating != null) ...[
              const SizedBox(width: 8),
              const Icon(Icons.star_rounded,
                  size: 14, color: AppColors.rating),
              const SizedBox(width: 2),
              Text(
                episode.rating!.toStringAsFixed(1),
                style: textTheme.bodySmall
                    ?.copyWith(fontWeight: FontWeight.w600),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

void _showEpisodeSheet(BuildContext context, EpisodeModel episode) {
  final textTheme = Theme.of(context).textTheme;
  final date = formatAirdate(episode.airdate);
  final summary = episode.plainSummary;

  showModalBottomSheet<void>(
    context: context,
    backgroundColor: AppColors.surface,
    isScrollControlled: true,
    showDragHandle: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (sheetContext) {
      return ConstrainedBox(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.sizeOf(sheetContext).height * 0.7,
        ),
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            20,
            0,
            20,
            24 + MediaQuery.paddingOf(sheetContext).bottom,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                episode.name,
                style: textTheme.titleLarge
                    ?.copyWith(fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 6),
              Text(
                [
                  episode.code,
                  if (date != null) date,
                  if (episode.runtime != null) '${episode.runtime} min',
                ].join(' · '),
                style: textTheme.bodySmall
                    ?.copyWith(color: AppColors.textSecondary),
              ),
              const SizedBox(height: 16),
              Text(
                summary ?? 'No summary available.',
                style: textTheme.bodyMedium?.copyWith(
                  height: 1.5,
                  color: summary == null
                      ? AppColors.textMuted
                      : AppColors.textSecondary,
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}
