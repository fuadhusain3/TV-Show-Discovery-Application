import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../blocs/show_details/show_details_bloc.dart';
import '../../../core/theme/app_colors.dart';

/// "Quick Info" card: status, network, genres, language.
class OverviewTab extends StatelessWidget {
  const OverviewTab({super.key});

  @override
  Widget build(BuildContext context) {
    final show = context.select((ShowDetailsBloc b) => b.state.show);
    if (show == null) return const SizedBox.shrink();

    final bottomInset = MediaQuery.paddingOf(context).bottom;

    return ListView(
      padding: EdgeInsets.fromLTRB(20, 20, 20, 24 + bottomInset),
      children: [
        Text(
          'Quick Info',
          style: Theme.of(context)
              .textTheme
              .titleMedium
              ?.copyWith(fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 12),
        Container(
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            children: [
              _InfoRow(
                icon: Icons.info_outline_rounded,
                label: 'Status',
                value: show.status,
              ),
              const Divider(height: 1),
              _InfoRow(
                icon: Icons.tv_rounded,
                label: 'Network',
                value: show.network,
              ),
              const Divider(height: 1),
              _InfoRow(
                icon: Icons.local_offer_outlined,
                label: 'Genres',
                value: show.genres.isEmpty ? null : show.genres.join(', '),
              ),
              const Divider(height: 1),
              _InfoRow(
                icon: Icons.language_rounded,
                label: 'Language',
                value: show.language,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.icon, required this.label, this.value});

  final IconData icon;
  final String label;
  final String? value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Icon(icon, size: 20, color: AppColors.textSecondary),
          const SizedBox(width: 12),
          Text(label, style: const TextStyle(color: AppColors.textSecondary)),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              value ?? '—',
              textAlign: TextAlign.end,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontWeight: FontWeight.w600,
                color: value == null
                    ? AppColors.textMuted
                    : AppColors.textPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
