import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../blocs/watchlist/watchlist_bloc.dart';
import '../../core/router/app_routes.dart';
import '../../core/theme/app_colors.dart';
import '../../widgets/centered_content.dart';

/// Small profile page: avatar, watchlist shortcut and data credit.
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    final bottomInset = MediaQuery.paddingOf(context).bottom;

    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: CenteredContent(
          child: ListView(
            padding: EdgeInsets.fromLTRB(20, 12, 20, 24 + bottomInset),
            children: [
              Text(
                'Profile',
                style: textTheme.headlineSmall
                    ?.copyWith(fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 28),
              const Center(
                child: CircleAvatar(
                  radius: 44,
                  backgroundColor: AppColors.surface,
                  child: Icon(
                    Icons.person_rounded,
                    size: 48,
                    color: AppColors.primary,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Center(
                child: Text(
                  'TV Explorer',
                  style: textTheme.titleLarge
                      ?.copyWith(fontWeight: FontWeight.w700),
                ),
              ),
              const SizedBox(height: 4),
              const Center(
                child: Text(
                  'Your personal TV guide',
                  style: TextStyle(color: AppColors.textSecondary),
                ),
              ),
              const SizedBox(height: 28),
              BlocSelector<WatchlistBloc, WatchlistState, int>(
                selector: (state) => state.shows.length,
                builder: (context, count) => _InfoCard(
                  children: [
                    _ActionRow(
                      icon: Icons.favorite_rounded,
                      iconColor: AppColors.favorite,
                      label: 'My Watchlist',
                      value: '$count ${count == 1 ? 'show' : 'shows'}',
                      onTap: () => context.go(AppRoutes.watchlist),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              const _InfoCard(
                children: [
                  _ActionRow(
                    icon: Icons.info_outline_rounded,
                    label: 'Data provided by',
                    value: 'TVMaze.com',
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.children});

  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(children: children),
    );
  }
}

class _ActionRow extends StatelessWidget {
  const _ActionRow({
    required this.icon,
    required this.label,
    required this.value,
    this.iconColor = AppColors.textSecondary,
    this.onTap,
  });

  final IconData icon;
  final Color iconColor;
  final String label;
  final String value;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        child: Row(
          children: [
            Icon(icon, size: 20, color: iconColor),
            const SizedBox(width: 12),
            Expanded(child: Text(label)),
            Text(value, style: const TextStyle(color: AppColors.textSecondary)),
            if (onTap != null) ...[
              const SizedBox(width: 4),
              const Icon(
                Icons.chevron_right_rounded,
                color: AppColors.textMuted,
              ),
            ],
          ],
        ),
      ),
    );
  }
}
