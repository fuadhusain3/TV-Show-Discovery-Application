import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../blocs/watchlist/watchlist_bloc.dart';
import '../../core/router/app_routes.dart';
import '../../core/theme/app_colors.dart';
import '../../widgets/centered_content.dart';
import '../../widgets/error_view.dart';
import '../../widgets/show_list_tile.dart';

class WatchlistScreen extends StatelessWidget {
  const WatchlistScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: BlocBuilder<WatchlistBloc, WatchlistState>(
          builder: (context, state) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _Header(count: state.shows.length),
                Expanded(child: _Body(state: state)),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.count});

  final int count;

  Future<void> _confirmClear(BuildContext context) async {
    final bloc = context.read<WatchlistBloc>();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Clear watchlist?'),
        content: const Text('All saved shows will be removed.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text(
              'Clear',
              style: TextStyle(color: AppColors.favorite),
            ),
          ),
        ],
      ),
    );
    if (confirmed == true) bloc.add(const WatchlistCleared());
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 8, 8),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'My Watchlist',
                  style: Theme.of(context)
                      .textTheme
                      .headlineSmall
                      ?.copyWith(fontWeight: FontWeight.w800),
                ),
                if (count > 0) ...[
                  const SizedBox(height: 2),
                  Text(
                    '$count ${count == 1 ? 'show' : 'shows'} saved',
                    style: Theme.of(context)
                        .textTheme
                        .bodySmall
                        ?.copyWith(color: AppColors.textSecondary),
                  ),
                ],
              ],
            ),
          ),
          if (count > 0)
            IconButton(
              tooltip: 'Clear watchlist',
              onPressed: () => _confirmClear(context),
              icon: const Icon(Icons.delete_outline_rounded),
            ),
        ],
      ),
    );
  }
}

class _Body extends StatelessWidget {
  const _Body({required this.state});

  final WatchlistState state;

  @override
  Widget build(BuildContext context) {
    switch (state.status) {
      case WatchlistStatus.initial:
      case WatchlistStatus.loading:
        return const Center(child: CircularProgressIndicator());

      case WatchlistStatus.failure:
        return ErrorView(
          message: state.errorMessage ?? 'Could not load your watchlist.',
          onRetry: () =>
              context.read<WatchlistBloc>().add(const WatchlistStarted()),
        );

      case WatchlistStatus.success:
        if (state.shows.isEmpty) return const _EmptyWatchlist();

        final bottomInset = MediaQuery.paddingOf(context).bottom;
        return CenteredContent(
          child: ListView.builder(
            padding: EdgeInsets.only(bottom: 16 + bottomInset),
            itemCount: state.shows.length,
            itemBuilder: (_, i) => ShowListTile(
              key: ValueKey(state.shows[i].id),
              show: state.shows[i],
            ),
          ),
        );
    }
  }
}

class _EmptyWatchlist extends StatelessWidget {
  const _EmptyWatchlist();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 140,
              height: 120,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppColors.primary.withValues(alpha: 0.12),
                    ),
                  ),
                  const Positioned(
                    bottom: 14,
                    child: Icon(
                      Icons.inventory_2_rounded,
                      size: 76,
                      color: AppColors.primary,
                    ),
                  ),
                  const Positioned(
                    top: 4,
                    child: Icon(
                      Icons.favorite_rounded,
                      size: 30,
                      color: AppColors.primary,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'Your watchlist is empty',
              textAlign: TextAlign.center,
              style: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            const Text(
              'Discover amazing shows and save them here to watch later.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.textSecondary),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: 200,
              child: ElevatedButton(
                onPressed: () => context.go(AppRoutes.home),
                child: const Text('Explore Shows'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
