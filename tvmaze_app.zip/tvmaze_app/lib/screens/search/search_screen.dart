import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../blocs/search/search_bloc.dart';
import '../../core/di/injector.dart';
import '../../core/theme/app_colors.dart';
import '../../widgets/centered_content.dart';
import '../../widgets/error_view.dart';
import '../../widgets/message_view.dart';
import '../../widgets/show_list_tile.dart';

class SearchScreen extends StatelessWidget {
  const SearchScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => sl<SearchBloc>(),
      child: const _SearchView(),
    );
  }
}

class _SearchView extends StatefulWidget {
  const _SearchView();

  @override
  State<_SearchView> createState() => _SearchViewState();
}

class _SearchViewState extends State<_SearchView> {
  final TextEditingController _textController = TextEditingController();

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  void _onChanged(String value) {
    context.read<SearchBloc>().add(SearchQueryChanged(value));
  }

  void _onClear() {
    _textController.clear();
    context.read<SearchBloc>().add(const SearchCleared());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
              child: TextField(
                controller: _textController,
                autofocus: true,
                textInputAction: TextInputAction.search,
                onChanged: _onChanged,
                decoration: InputDecoration(
                  hintText: 'Search shows...',
                  prefixIcon: const Icon(Icons.search_rounded,
                      color: AppColors.textMuted),
                  suffixIcon: ValueListenableBuilder<TextEditingValue>(
                    valueListenable: _textController,
                    builder: (_, value, __) => value.text.isEmpty
                        ? const SizedBox.shrink()
                        : IconButton(
                            icon: const Icon(Icons.cancel_rounded,
                                color: AppColors.textMuted),
                            onPressed: _onClear,
                          ),
                  ),
                ),
              ),
            ),
            const Expanded(child: _SearchBody()),
          ],
        ),
      ),
    );
  }
}

class _SearchBody extends StatelessWidget {
  const _SearchBody();

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SearchBloc, SearchState>(
      builder: (context, state) {
        switch (state.status) {
          case SearchStatus.initial:
            return const MessageView(
              icon: Icons.search_rounded,
              title: 'Find your favorite shows',
              subtitle: 'Start typing a title to see results.',
            );

          case SearchStatus.loading:
            // First search: spinner. Refining a search: keep the old list
            // visible under a thin progress bar.
            if (state.results.isEmpty) {
              return const Center(child: CircularProgressIndicator());
            }
            return Column(
              children: [
                const LinearProgressIndicator(minHeight: 2),
                Expanded(child: _ResultsList(state: state)),
              ],
            );

          case SearchStatus.failure:
            return ErrorView(
              message: state.errorMessage ?? 'Something went wrong.',
              onRetry: () =>
                  context.read<SearchBloc>().add(const SearchRetried()),
            );

          case SearchStatus.success:
            if (state.isEmptyResult) {
              return MessageView(
                icon: Icons.search_off_rounded,
                title: 'No shows found for “${state.query}”',
                subtitle: 'Check the spelling or try a different title.',
              );
            }
            return _ResultsList(state: state);
        }
      },
    );
  }
}

class _ResultsList extends StatelessWidget {
  const _ResultsList({required this.state});

  final SearchState state;

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.paddingOf(context).bottom;
    return CenteredContent(
      child: ListView.builder(
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        padding: EdgeInsets.only(bottom: 16 + bottomInset),
        itemCount: state.results.length,
        itemBuilder: (_, i) => ShowListTile(show: state.results[i]),
      ),
    );
  }
}
