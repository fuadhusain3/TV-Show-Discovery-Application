part of 'home_bloc.dart';

sealed class HomeEvent extends Equatable {
  const HomeEvent();

  @override
  List<Object?> get props => [];
}

/// Load the first page (also used by the full-screen "Retry" button).
class HomeStarted extends HomeEvent {
  const HomeStarted();
}

/// Load the next page (infinite scroll, also the footer "Retry" button).
class HomeLoadMoreRequested extends HomeEvent {
  const HomeLoadMoreRequested();
}

/// Pull-to-refresh. The [completer] resolves to `true` on success so the UI
/// can stop the spinner and report failures.
class HomeRefreshed extends HomeEvent {
  const HomeRefreshed(this.completer);

  final Completer<bool> completer;

  @override
  List<Object?> get props => [completer];
}
