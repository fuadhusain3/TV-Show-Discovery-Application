part of 'home_bloc.dart';

enum HomeStatus { initial, loading, success, failure }

class HomeState extends Equatable {
  const HomeState({
    this.status = HomeStatus.initial,
    this.shows = const [],
    this.trending = const [],
    this.nextPage = 0,
    this.hasReachedMax = false,
    this.isLoadingMore = false,
    this.errorMessage,
    this.loadMoreError,
  });

  final HomeStatus status;
  final List<ShowModel> shows;
  final List<ShowModel> trending;

  final int nextPage; //index of 1st page to end
  final bool hasReachedMax;
  final bool isLoadingMore;

  final String? errorMessage; //set when page fails to load anytime
  final String? loadMoreError;

  HomeState copyWith({
    HomeStatus? status,
    List<ShowModel>? shows,
    List<ShowModel>? trending,
    int? nextPage,
    bool? hasReachedMax,
    bool? isLoadingMore,
    String? errorMessage,
    String? loadMoreError,
    bool clearErrors = false,
  }) {
    return HomeState(
      status: status ?? this.status,
      shows: shows ?? this.shows,
      trending: trending ?? this.trending,
      nextPage: nextPage ?? this.nextPage,
      hasReachedMax: hasReachedMax ?? this.hasReachedMax,
      isLoadingMore: isLoadingMore ?? this.isLoadingMore,
      errorMessage: clearErrors ? null : (errorMessage ?? this.errorMessage),
      loadMoreError:
          clearErrors ? null : (loadMoreError ?? this.loadMoreError),
    );
  }

  @override
  List<Object?> get props => [
        status,
        shows,
        trending,
        nextPage,
        hasReachedMax,
        isLoadingMore,
        errorMessage,
        loadMoreError,
      ];
}
