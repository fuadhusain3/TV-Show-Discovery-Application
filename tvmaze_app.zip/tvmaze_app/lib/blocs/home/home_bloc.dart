import 'dart:async';

import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../core/network/api_exception.dart';
import '../../models/show_model.dart';
import '../../repositories/show_repository.dart';

part 'home_event.dart';
part 'home_state.dart';

class HomeBloc extends Bloc<HomeEvent, HomeState> {
  HomeBloc(this._repository) : super(const HomeState()) {
    on<HomeStarted>(_onStarted);
    on<HomeLoadMoreRequested>(_onLoadMore);
    on<HomeRefreshed>(_onRefreshed);
  }

  final ShowRepository _repository;

  static const int _trendingCount = 10;
  static const String _genericError = 'Something went wrong. Please retry.';

  Future<void> _onStarted(HomeStarted event, Emitter<HomeState> emit) async {
    if (state.status == HomeStatus.loading) return;
    emit(state.copyWith(status: HomeStatus.loading, clearErrors: true));

    try {
      final shows = await _repository.getShows(page: 0);
      emit(_firstPageState(shows));
    } on ApiException catch (e) {
      emit(state.copyWith(status: HomeStatus.failure, errorMessage: e.message));
    } catch (_) {
      emit(state.copyWith(
        status: HomeStatus.failure,
        errorMessage: _genericError,
      ));
    }
  }

  Future<void> _onLoadMore(
    HomeLoadMoreRequested event,
    Emitter<HomeState> emit,
  ) async {
    // Ignore duplicate scroll triggers and finished lists.
    if (state.status != HomeStatus.success ||
        state.isLoadingMore ||
        state.hasReachedMax) {
      return;
    }
    final page = state.nextPage;
    emit(state.copyWith(isLoadingMore: true, clearErrors: true));

    try {
      final more = await _repository.getShows(page: page);
      // A refresh finished while this page was loading: the list was reset,
      // so this page no longer belongs to it.
      if (state.nextPage != page) return;

      final known = {for (final show in state.shows) show.id};
      emit(state.copyWith(
        shows: [...state.shows, ...more.where((s) => !known.contains(s.id))],
        nextPage: page + 1,
        hasReachedMax: more.isEmpty,
        isLoadingMore: false,
      ));
    } on ApiException catch (e) {
      if (state.nextPage != page) return;
      emit(state.copyWith(isLoadingMore: false, loadMoreError: e.message));
    } catch (_) {
      if (state.nextPage != page) return;
      emit(state.copyWith(isLoadingMore: false, loadMoreError: _genericError));
    }
  }

  Future<void> _onRefreshed(
    HomeRefreshed event,
    Emitter<HomeState> emit,
  ) async {
    try {
      final shows = await _repository.getShows(page: 0);
      emit(_firstPageState(shows));
      event.completer.complete(true);
    } catch (_) {
      // Keep the data already on screen; the UI reports the failure.
      event.completer.complete(false);
    }
  }

  HomeState _firstPageState(List<ShowModel> shows) {
    return HomeState(
      status: HomeStatus.success,
      shows: shows,
      trending: _pickTrending(shows),
      nextPage: 1,
      hasReachedMax: shows.isEmpty,
    );
  }

  /// Highest-rated shows that have a poster and a rating.
  List<ShowModel> _pickTrending(List<ShowModel> shows) {
    final candidates = shows
        .where((s) => s.rating != null && s.posterUrl != null)
        .toList()
      ..sort((a, b) {
        final byRating = b.rating!.compareTo(a.rating!);
        return byRating != 0 ? byRating : b.weight.compareTo(a.weight);
      });
    return candidates.take(_trendingCount).toList();
  }
}
