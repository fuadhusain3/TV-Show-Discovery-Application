part of 'show_details_bloc.dart';

sealed class ShowDetailsEvent extends Equatable {
  const ShowDetailsEvent();

  @override
  List<Object?> get props => [];
}

/// Load the show, its cast and its episodes. If [initialShow] is given (it comes from the list the user tapped) it is shown immediately while fresh data loads.
class ShowDetailsStarted extends ShowDetailsEvent {
  const ShowDetailsStarted(this.showId, {this.initialShow});

  final int showId;
  final ShowModel? initialShow;

  @override
  List<Object?> get props => [showId, initialShow];
}

class ShowDetailsCastRetried extends ShowDetailsEvent {
  const ShowDetailsCastRetried();
}

class ShowDetailsEpisodesRetried extends ShowDetailsEvent {
  const ShowDetailsEpisodesRetried();
}

class ShowDetailsSeasonSelected extends ShowDetailsEvent {
  const ShowDetailsSeasonSelected(this.season);

  final int season;

  @override
  List<Object?> get props => [season];
}
