part of 'show_details_bloc.dart';

enum LoadStatus { initial, loading, success, failure }

/// Details, cast and episodes load independently, so a failure in one section never hides the others.

class ShowDetailsState extends Equatable {
  const ShowDetailsState({
    this.showId = 0,
    this.show,
    this.detailsStatus = LoadStatus.initial,
    this.detailsError,
    this.cast = const [],
    this.castStatus = LoadStatus.initial,
    this.castError,
    this.seasons = const {},
    this.selectedSeason,
    this.episodesStatus = LoadStatus.initial,
    this.episodesError,
  });

  final int showId;
  final ShowModel? show;
  final LoadStatus detailsStatus;
  final String? detailsError;

  final List<CastMemberModel> cast;
  final LoadStatus castStatus;
  final String? castError;

  /// Episodes grouped by season number (ascending).
  final Map<int, List<EpisodeModel>> seasons;
  final int? selectedSeason;
  final LoadStatus episodesStatus;
  final String? episodesError;

  int get seasonCount => seasons.length;

  List<EpisodeModel> get selectedEpisodes =>
      seasons[selectedSeason] ?? const [];

  /// Each section's error is replaced whenever its status is updated, so an
  /// old message never outlives a retry.
  ShowDetailsState copyWith({
    ShowModel? show,
    LoadStatus? detailsStatus,
    String? detailsError,
    List<CastMemberModel>? cast,
    LoadStatus? castStatus,
    String? castError,
    Map<int, List<EpisodeModel>>? seasons,
    int? selectedSeason,
    LoadStatus? episodesStatus,
    String? episodesError,
  }) {
    return ShowDetailsState(
      showId: showId,
      show: show ?? this.show,
      detailsStatus: detailsStatus ?? this.detailsStatus,
      detailsError: detailsStatus == null ? this.detailsError : detailsError,
      cast: cast ?? this.cast,
      castStatus: castStatus ?? this.castStatus,
      castError: castStatus == null ? this.castError : castError,
      seasons: seasons ?? this.seasons,
      selectedSeason: selectedSeason ?? this.selectedSeason,
      episodesStatus: episodesStatus ?? this.episodesStatus,
      episodesError: episodesStatus == null ? this.episodesError : episodesError,
    );
  }

  @override
  List<Object?> get props => [
        showId,
        show,
        detailsStatus,
        detailsError,
        cast,
        castStatus,
        castError,
        seasons,
        selectedSeason,
        episodesStatus,
        episodesError,
      ];
}
