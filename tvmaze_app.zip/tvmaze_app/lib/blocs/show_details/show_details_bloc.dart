import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../core/network/api_exception.dart';
import '../../models/cast_member_model.dart';
import '../../models/episode_model.dart';
import '../../models/show_model.dart';
import '../../repositories/show_repository.dart';

part 'show_details_event.dart';
part 'show_details_state.dart';

class ShowDetailsBloc extends Bloc<ShowDetailsEvent, ShowDetailsState> {
  ShowDetailsBloc(this._repository) : super(const ShowDetailsState()) {
    on<ShowDetailsStarted>(_onStarted);
    on<ShowDetailsCastRetried>(_onCastRetried);
    on<ShowDetailsEpisodesRetried>(_onEpisodesRetried);
    on<ShowDetailsSeasonSelected>(_onSeasonSelected);
  }

  final ShowRepository _repository;

  static const String _genericError = 'Something went wrong. Please retry.';

  Future<void> _onStarted(
    ShowDetailsStarted event,
    Emitter<ShowDetailsState> emit,
  ) async {
    final initial = event.initialShow;
    emit(ShowDetailsState(
      showId: event.showId,
      show: initial,
      // With a show from the list we can render right away.
      detailsStatus: initial != null ? LoadStatus.success : LoadStatus.loading,
      castStatus: LoadStatus.loading,
      episodesStatus: LoadStatus.loading,
    ));

    // The three requests run in parallel and report independently.
    await Future.wait([
      _loadDetails(emit),
      _loadCast(emit),
      _loadEpisodes(emit),
    ]);
  }

  Future<void> _onCastRetried(
    ShowDetailsCastRetried event,
    Emitter<ShowDetailsState> emit,
  ) async {
    emit(state.copyWith(castStatus: LoadStatus.loading));
    await _loadCast(emit);
  }

  Future<void> _onEpisodesRetried(
    ShowDetailsEpisodesRetried event,
    Emitter<ShowDetailsState> emit,
  ) async {
    emit(state.copyWith(episodesStatus: LoadStatus.loading));
    await _loadEpisodes(emit);
  }

  void _onSeasonSelected(
    ShowDetailsSeasonSelected event,
    Emitter<ShowDetailsState> emit,
  ) {
    if (state.seasons.containsKey(event.season)) {
      emit(state.copyWith(selectedSeason: event.season));
    }
  }

  Future<void> _loadDetails(Emitter<ShowDetailsState> emit) async {
    try {
      final show = await _repository.getShowDetails(state.showId);
      emit(state.copyWith(show: show, detailsStatus: LoadStatus.success));
    } on ApiException catch (e) {
      _detailsFailed(emit, e.message);
    } catch (_) {
      _detailsFailed(emit, _genericError);
    }
  }

  void _detailsFailed(Emitter<ShowDetailsState> emit, String message) {
    // If the list already gave us the show, keep showing it.
    if (state.show != null) return;
    emit(state.copyWith(
      detailsStatus: LoadStatus.failure,
      detailsError: message,
    ));
  }

  Future<void> _loadCast(Emitter<ShowDetailsState> emit) async {
    try {
      final cast = await _repository.getCast(state.showId);
      emit(state.copyWith(cast: cast, castStatus: LoadStatus.success));
    } on ApiException catch (e) {
      emit(state.copyWith(
        castStatus: LoadStatus.failure,
        castError: e.message,
      ));
    } catch (_) {
      emit(state.copyWith(
        castStatus: LoadStatus.failure,
        castError: _genericError,
      ));
    }
  }

  Future<void> _loadEpisodes(Emitter<ShowDetailsState> emit) async {
    try {
      final seasons = await _repository.getEpisodesBySeason(state.showId);
      emit(state.copyWith(
        seasons: seasons,
        selectedSeason: seasons.keys.firstOrNull,
        episodesStatus: LoadStatus.success,
      ));
    } on ApiException catch (e) {
      emit(state.copyWith(
        episodesStatus: LoadStatus.failure,
        episodesError: e.message,
      ));
    } catch (_) {
      emit(state.copyWith(
        episodesStatus: LoadStatus.failure,
        episodesError: _genericError,
      ));
    }
  }
}
