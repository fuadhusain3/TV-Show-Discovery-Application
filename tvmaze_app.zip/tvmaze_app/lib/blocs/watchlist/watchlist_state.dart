part of 'watchlist_bloc.dart';

enum WatchlistStatus { initial, loading, success, failure }

class WatchlistState extends Equatable {
  const WatchlistState({
    this.status = WatchlistStatus.initial,
    this.shows = const [],
    this.errorMessage,
    this.failureCount = 0,
  });

  final WatchlistStatus status;

  /// Saved shows, newest first.
  final List<ShowModel> shows;
  final String? errorMessage;

  /// Increases on every failure so the UI can show a message each time,
  /// even when the text is identical.
  final int failureCount;

  bool contains(int showId) => shows.any((s) => s.id == showId);

  WatchlistState copyWith({
    WatchlistStatus? status,
    List<ShowModel>? shows,
    String? errorMessage,
    bool clearError = false,
    bool failed = false,
  }) {
    return WatchlistState(
      status: status ?? this.status,
      shows: shows ?? this.shows,
      errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
      failureCount: failed ? failureCount + 1 : failureCount,
    );
  }

  @override
  List<Object?> get props => [status, shows, errorMessage, failureCount];
}
