part of 'watchlist_bloc.dart';

sealed class WatchlistEvent extends Equatable {
  const WatchlistEvent();

  @override
  List<Object?> get props => [];
}

/// Load the saved watchlist from the device (app start / retry).
class WatchlistStarted extends WatchlistEvent {
  const WatchlistStarted();
}

class WatchlistShowAdded extends WatchlistEvent {
  const WatchlistShowAdded(this.show);

  final ShowModel show;

  @override
  List<Object?> get props => [show];
}

class WatchlistShowRemoved extends WatchlistEvent {
  const WatchlistShowRemoved(this.showId);

  final int showId;

  @override
  List<Object?> get props => [showId];
}

/// Heart button: add the show if it is not saved, remove it if it is.
class WatchlistToggled extends WatchlistEvent {
  const WatchlistToggled(this.show);

  final ShowModel show;

  @override
  List<Object?> get props => [show];
}

class WatchlistCleared extends WatchlistEvent {
  const WatchlistCleared();
}
