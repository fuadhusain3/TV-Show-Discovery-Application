import 'package:bloc_concurrency/bloc_concurrency.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../models/show_model.dart';
import '../../repositories/watchlist_repository.dart';

part 'watchlist_event.dart';
part 'watchlist_state.dart';

/// App-wide BLoC (provided in app.dart) so every heart button and the watchlist tab always agree.
class WatchlistBloc extends Bloc<WatchlistEvent, WatchlistState> {
  WatchlistBloc(this._repository) : super(const WatchlistState()) {
    // One handler (and therefore one queue) for every event type: storage is
    // read-modify-write, so taps, undo and clear must never interleave, even
    // when they are different event types.
    on<WatchlistEvent>(_onEvent, transformer: sequential());
  }

  final WatchlistRepository _repository;

  static const String _updateError =
      'Could not update your watchlist. Please try again.';

  Future<void> _onEvent(
    WatchlistEvent event,
    Emitter<WatchlistState> emit,
  ) {
    return switch (event) {
      WatchlistStarted() => _onStarted(emit),
      WatchlistShowAdded(:final show) => _onAdded(show, emit),
      WatchlistShowRemoved(:final showId) => _onRemoved(showId, emit),
      WatchlistToggled(:final show) => _onToggled(show, emit),
      WatchlistCleared() => _onCleared(emit),
    };
  }

  Future<void> _onStarted(Emitter<WatchlistState> emit) async {
    emit(state.copyWith(status: WatchlistStatus.loading, clearError: true));
    try {
      final shows = await _repository.getWatchlist();
      emit(state.copyWith(status: WatchlistStatus.success, shows: shows));
    } catch (_) {
      emit(state.copyWith(
        status: WatchlistStatus.failure,
        errorMessage: 'Could not load your watchlist.',
      ));
    }
  }

  Future<void> _onAdded(ShowModel show, Emitter<WatchlistState> emit) async {
    if (state.contains(show.id)) return;
    await _apply(emit, () => _repository.add(show));
  }

  Future<void> _onRemoved(int showId, Emitter<WatchlistState> emit) async {
    if (!state.contains(showId)) return;
    await _apply(emit, () => _repository.remove(showId));
  }

  Future<void> _onToggled(ShowModel show, Emitter<WatchlistState> emit) async {
    if (state.contains(show.id)) {
      await _apply(emit, () => _repository.remove(show.id));
    } else {
      await _apply(emit, () => _repository.add(show));
    }
  }

  Future<void> _onCleared(Emitter<WatchlistState> emit) async {
    if (state.shows.isEmpty) return;
    await _apply(emit, _repository.clear);
  }

  /// Runs a repository change and publishes the saved result. On failure the
  /// list on screen stays as it was and an error is reported.
  Future<void> _apply(
    Emitter<WatchlistState> emit,
    Future<List<ShowModel>> Function() action,
  ) async {
    try {
      final shows = await action();
      emit(state.copyWith(
        status: WatchlistStatus.success,
        shows: shows,
        clearError: true,
      ));
    } catch (_) {
      emit(state.copyWith(errorMessage: _updateError, failed: true));
    }
  }
}
