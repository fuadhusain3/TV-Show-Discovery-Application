part of 'search_bloc.dart';

sealed class SearchEvent extends Equatable {
  const SearchEvent();

  @override
  List<Object?> get props => [];
}

/// The text in the search field changed by the BLoC, except when the query is empty (that clears the results immediately).
class SearchQueryChanged extends SearchEvent {
  const SearchQueryChanged(this.query);

  final String query;

  @override
  List<Object?> get props => [query];
}

/// The user tapped the clear button.
class SearchCleared extends SearchQueryChanged {
  const SearchCleared() : super('');
}

/// Re-run the current query after a failure (no debounce).
class SearchRetried extends SearchEvent {
  const SearchRetried();
}
