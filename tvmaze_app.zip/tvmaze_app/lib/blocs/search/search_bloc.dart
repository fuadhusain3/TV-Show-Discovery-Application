import 'dart:async';

import 'package:bloc_concurrency/bloc_concurrency.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:stream_transform/stream_transform.dart';

import '../../core/network/api_exception.dart';
import '../../models/show_model.dart';
import '../../repositories/show_repository.dart';

part 'search_event.dart';
part 'search_state.dart';

class SearchBloc extends Bloc<SearchEvent, SearchState> {
  SearchBloc(this._repository) : super(const SearchState()) {
    on<SearchQueryChanged>(_onQueryChanged, transformer: _debounceRestartable());
    on<SearchRetried>(_onRetried, transformer: restartable());
  }

  final ShowRepository _repository;

  static const Duration debounceDuration = Duration(milliseconds: 500);
  static const String _genericError = 'Something went wrong. Please retry.';

  /// Waits for a pause before searching and cancels request when a newer query arrives. Empty queries skip the
  /// wait so clearing the field resets the screen instantly.
  static EventTransformer<SearchQueryChanged> _debounceRestartable() {
    return (events, mapper) {
      final debounced = events.switchMap<SearchQueryChanged>(
        (event) => event.query.trim().isEmpty
            ? Stream.value(event)
            : Stream.fromFuture(
                Future<SearchQueryChanged>.delayed(
                  debounceDuration,
                  () => event,
                ),
              ),
      );
      return restartable<SearchQueryChanged>().call(debounced, mapper);
    };
  }

  Future<void> _onQueryChanged(
    SearchQueryChanged event,
    Emitter<SearchState> emit,
  ) async {
    final query = event.query.trim();
    if (query.isEmpty) {
      emit(const SearchState());
      return;
    }
    await _search(query, emit);
  }

  Future<void> _onRetried(
    SearchRetried event,
    Emitter<SearchState> emit,
  ) async {
    if (state.query.isEmpty) return;
    await _search(state.query, emit);
  }

  Future<void> _search(String query, Emitter<SearchState> emit) async {
    // Previous results stay visible while the new ones load.
    emit(state.copyWith(
      status: SearchStatus.loading,
      query: query,
      clearError: true,
    ));

    try {
      final results = await _repository.searchShows(query);
      emit(state.copyWith(status: SearchStatus.success, results: results));
    } on ApiException catch (e) {
      emit(state.copyWith(
        status: SearchStatus.failure,
        results: const [],
        errorMessage: e.message,
      ));
    } catch (_) {
      emit(state.copyWith(
        status: SearchStatus.failure,
        results: const [],
        errorMessage: _genericError,
      ));
    }
  }
}
