part of 'search_bloc.dart';

enum SearchStatus { initial, loading, success, failure }

class SearchState extends Equatable {
  const SearchState({
    this.status = SearchStatus.initial,
    this.query = '',
    this.results = const [],
    this.errorMessage,
  });

  final SearchStatus status;

  final String query;
  final List<ShowModel> results;
  final String? errorMessage;

  /// A finished search that matched nothing.
  bool get isEmptyResult =>
      status == SearchStatus.success && results.isEmpty;

  SearchState copyWith({
    SearchStatus? status,
    String? query,
    List<ShowModel>? results,
    String? errorMessage,
    bool clearError = false,
  }) {
    return SearchState(
      status: status ?? this.status,
      query: query ?? this.query,
      results: results ?? this.results,
      errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
    );
  }

  @override
  List<Object?> get props => [status, query, results, errorMessage];
}
