import 'package:equatable/equatable.dart';

import '../core/utils/json_utils.dart';

/// One entry of GET /shows/{id}/cast: an actor and the character they play.
class CastMemberModel extends Equatable {
  const CastMemberModel({
    required this.personId,
    required this.personName,
    this.characterName,
    this.imageUrl,
  });

  factory CastMemberModel.fromJson(Map<String, dynamic> json) {
    final person = asMap(json['person']) ?? const <String, dynamic>{};
    final character = asMap(json['character']) ?? const <String, dynamic>{};
    final personImage = asMap(person['image']);
    final characterImage = asMap(character['image']);

    return CastMemberModel(
      personId: (person['id'] as num?)?.toInt() ?? 0,
      personName: nonEmptyString(person['name']) ?? 'Unknown',
      characterName: nonEmptyString(character['name']),
      // Prefer the actor's photo, fall back to the character artwork.
      imageUrl: secureUrl(personImage?['medium']) ??
          secureUrl(characterImage?['medium']),
    );
  }

  final int personId;
  final String personName;
  final String? characterName;
  final String? imageUrl;

  @override
  List<Object?> get props => [personId, personName, characterName, imageUrl];
}
