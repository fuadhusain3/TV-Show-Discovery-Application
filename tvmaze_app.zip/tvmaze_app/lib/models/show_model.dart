import 'package:equatable/equatable.dart';

import '../core/utils/html_utils.dart';
import '../core/utils/json_utils.dart';

/// A TV show as returned by the TVMaze API.
///
/// Every field except [id] is optional-safe: the API often returns `null`
/// for images, ratings, genres, networks, etc., so parsing never throws on
/// missing data.
class ShowModel extends Equatable {
  const ShowModel({
    required this.id,
    required this.name,
    this.genres = const [],
    this.rating,
    this.imageMediumUrl,
    this.imageOriginalUrl,
    this.premiered,
    this.ended,
    this.status,
    this.language,
    this.summary,
    this.network,
    this.weight = 0,
  });

  factory ShowModel.fromJson(Map<String, dynamic> json) {
    final image = asMap(json['image']);
    final rating = asMap(json['rating']);
    final network = asMap(json['network']) ?? asMap(json['webChannel']);

    return ShowModel(
      id: (json['id'] as num).toInt(),
      name: nonEmptyString(json['name']) ?? 'Untitled',
      genres: (json['genres'] as List?)?.whereType<String>().toList() ??
          const [],
      rating: (rating?['average'] as num?)?.toDouble(),
      imageMediumUrl: secureUrl(image?['medium']),
      imageOriginalUrl: secureUrl(image?['original']),
      premiered: nonEmptyString(json['premiered']),
      ended: nonEmptyString(json['ended']),
      status: nonEmptyString(json['status']),
      language: nonEmptyString(json['language']),
      summary: nonEmptyString(json['summary']),
      network: nonEmptyString(network?['name']),
      weight: (json['weight'] as num?)?.toInt() ?? 0,
    );
  }

  final int id;
  final String name;
  final List<String> genres;
  final double? rating;
  final String? imageMediumUrl;
  final String? imageOriginalUrl;
  final String? premiered;
  final String? ended;
  final String? status;
  final String? language;

  /// HTML text straight from the API (strip tags when displaying).
  final String? summary;
  final String? network;

  /// TVMaze popularity score (0-100).
  final int weight;

  /// Serialises in the same shape the TVMaze API uses, so [ShowModel.fromJson]
  /// can read it back (used by the local watchlist storage).
  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'genres': genres,
        'rating': {'average': rating},
        'image': (imageMediumUrl == null && imageOriginalUrl == null)
            ? null
            : {'medium': imageMediumUrl, 'original': imageOriginalUrl},
        'premiered': premiered,
        'ended': ended,
        'status': status,
        'language': language,
        'summary': summary,
        'network': network == null ? null : {'name': network},
        'weight': weight,
      };

  /// Best image for list cards, `null` when the show has no artwork.
  String? get posterUrl => imageMediumUrl ?? imageOriginalUrl;

  /// Summary with the HTML tags/entities removed, `null` when missing.
  String? get plainSummary {
    final text = stripHtml(summary);
    return text.isEmpty ? null : text;
  }

  /// "Drama, Crime" (max two genres) or `null` when there are none.
  String? get genresLabel =>
      genres.isEmpty ? null : genres.take(2).join(', ');

  /// Premiere year, e.g. "2008".
  String? get year {
    final p = premiered;
    return (p != null && p.length >= 4) ? p.substring(0, 4) : null;
  }

  /// "2008 - 2013", "2023 - Present", or just "2008"; `null` if unknown.
  String? get yearsLabel {
    final start = year;
    if (start == null) return null;
    final e = ended;
    final end = (e != null && e.length >= 4) ? e.substring(0, 4) : null;
    if (end != null) return end == start ? start : '$start - $end';
    return status == 'Ended' ? start : '$start - Present';
  }

  @override
  List<Object?> get props => [
        id,
        name,
        genres,
        rating,
        imageMediumUrl,
        imageOriginalUrl,
        premiered,
        ended,
        status,
        language,
        summary,
        network,
        weight,
      ];
}
