import 'package:equatable/equatable.dart';

import '../core/utils/html_utils.dart';
import '../core/utils/json_utils.dart';

/// One episode from GET /shows/{id}/episodes.
class EpisodeModel extends Equatable {
  const EpisodeModel({
    required this.id,
    required this.name,
    required this.season,
    this.number,
    this.airdate,
    this.runtime,
    this.rating,
    this.imageUrl,
    this.summary,
  });

  factory EpisodeModel.fromJson(Map<String, dynamic> json) {
    final image = asMap(json['image']);
    return EpisodeModel(
      id: (json['id'] as num).toInt(),
      name: nonEmptyString(json['name']) ?? 'Untitled episode',
      season: (json['season'] as num?)?.toInt() ?? 0,
      // `number` is null for specials.
      number: (json['number'] as num?)?.toInt(),
      airdate: nonEmptyString(json['airdate']),
      runtime: (json['runtime'] as num?)?.toInt(),
      rating: (asMap(json['rating'])?['average'] as num?)?.toDouble(),
      imageUrl: secureUrl(image?['medium']) ?? secureUrl(image?['original']),
      summary: nonEmptyString(json['summary']),
    );
  }

  final int id;
  final String name;
  final int season;
  final int? number;
  final String? airdate;
  final int? runtime;
  final double? rating;
  final String? imageUrl;
  final String? summary;

  String? get plainSummary {
    final text = stripHtml(summary);
    return text.isEmpty ? null : text;
  }

  /// "S1 · E3" (or "S1 · Special").
  String get code => 'S$season · ${number != null ? 'E$number' : 'Special'}';

  @override
  List<Object?> get props =>
      [id, name, season, number, airdate, runtime, rating, imageUrl, summary];
}
