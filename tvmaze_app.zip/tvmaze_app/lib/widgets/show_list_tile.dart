import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../core/router/app_routes.dart';
import '../core/theme/app_colors.dart';
import '../models/show_model.dart';
import 'poster_image.dart';
import 'watchlist_button.dart';

/// Horizontal row: poster, title, years + rating, genres, chevron.
/// Used by search results (and reusable for the watchlist).
class ShowListTile extends StatelessWidget {
  const ShowListTile({super.key, required this.show});

  final ShowModel show;

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    final years = show.yearsLabel;
    final rating = show.rating;

    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => context.push(AppRoutes.showDetails(show.id), extra: show),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        child: Row(
          children: [
            SizedBox(
              width: 58,
              height: 84,
              child: PosterImage(url: show.posterUrl, borderRadius: 8),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    show.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: textTheme.bodyLarge
                        ?.copyWith(fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      if (years != null)
                        Flexible(
                          child: Text(
                            years,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: textTheme.bodySmall
                                ?.copyWith(color: AppColors.textSecondary),
                          ),
                        ),
                      if (years != null && rating != null)
                        const SizedBox(width: 10),
                      if (rating != null) ...[
                        const Icon(Icons.star_rounded,
                            size: 14, color: AppColors.rating),
                        const SizedBox(width: 2),
                        Text(
                          rating.toStringAsFixed(1),
                          style: textTheme.bodySmall?.copyWith(
                            color: AppColors.textPrimary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    show.genresLabel ?? 'Genre unavailable',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: textTheme.bodySmall
                        ?.copyWith(color: AppColors.textMuted),
                  ),
                ],
              ),
            ),
            WatchlistHeartButton(
              show: show,
              iconSize: 20,
              withBackground: false,
            ),
            const Icon(Icons.chevron_right_rounded,
                color: AppColors.textMuted),
          ],
        ),
      ),
    );
  }
}
