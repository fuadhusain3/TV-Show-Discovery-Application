import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../blocs/watchlist/watchlist_bloc.dart';
import '../core/theme/app_colors.dart';
import '../models/show_model.dart';

/// Adds/removes [show] and confirms with a snackbar (with UNDO on removal).
void toggleWatchlist(BuildContext context, ShowModel show) {
  final bloc = context.read<WatchlistBloc>();
  final messenger = ScaffoldMessenger.of(context);
  final wasSaved = bloc.state.contains(show.id);

  bloc.add(WatchlistToggled(show));

  messenger
    ..hideCurrentSnackBar()
    ..showSnackBar(
      SnackBar(
        duration: const Duration(seconds: 3),
        content: Text(
          wasSaved
              ? 'Removed “${show.name}” from your watchlist'
              : 'Added “${show.name}” to your watchlist',
        ),
        action: wasSaved
            ? SnackBarAction(
                label: 'UNDO',
                onPressed: () => bloc.add(WatchlistShowAdded(show)),
              )
            : null,
      ),
    );
}

/// Heart icon that reflects and toggles the watchlist state of [show].
/// Round dark background on posters; plain icon in list rows.
class WatchlistHeartButton extends StatelessWidget {
  const WatchlistHeartButton({
    super.key,
    required this.show,
    this.iconSize = 18,
    this.withBackground = true,
  });

  final ShowModel show;
  final double iconSize;
  final bool withBackground;

  @override
  Widget build(BuildContext context) {
    return BlocSelector<WatchlistBloc, WatchlistState, bool>(
      selector: (state) => state.contains(show.id),
      builder: (context, saved) {
        final icon = Icon(
          saved ? Icons.favorite_rounded : Icons.favorite_border_rounded,
          size: iconSize,
          color: saved
              ? AppColors.favorite
              : (withBackground ? Colors.white : AppColors.textSecondary),
        );

        return Tooltip(
          message: saved ? 'Remove from watchlist' : 'Add to watchlist',
          child: Material(
            color: withBackground ? const Color(0x99000000) : Colors.transparent,
            shape: const CircleBorder(),
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: () => toggleWatchlist(context, show),
              child: Padding(padding: const EdgeInsets.all(8), child: icon),
            ),
          ),
        );
      },
    );
  }
}

/// Wide "Add to Watchlist" / "In Watchlist" button for the details screen.
class WatchlistToggleButton extends StatelessWidget {
  const WatchlistToggleButton({super.key, required this.show});

  final ShowModel show;

  @override
  Widget build(BuildContext context) {
    return BlocSelector<WatchlistBloc, WatchlistState, bool>(
      selector: (state) => state.contains(show.id),
      builder: (context, saved) {
        void onPressed() => toggleWatchlist(context, show);

        return SizedBox(
          width: double.infinity,
          child: saved
              ? OutlinedButton.icon(
                  onPressed: onPressed,
                  icon: const Icon(Icons.check_rounded),
                  label: const Text('In Watchlist'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.textPrimary,
                    minimumSize: const Size.fromHeight(48),
                    side: const BorderSide(color: AppColors.primary),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    textStyle: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                )
              : ElevatedButton.icon(
                  onPressed: onPressed,
                  icon: const Icon(Icons.add_rounded),
                  label: const Text('Add to Watchlist'),
                ),
        );
      },
    );
  }
}
