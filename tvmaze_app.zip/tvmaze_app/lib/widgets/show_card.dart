import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../core/router/app_routes.dart';
import '../core/theme/app_colors.dart';
import '../models/show_model.dart';
import 'poster_image.dart';
import 'rating_badge.dart';
import 'watchlist_button.dart';

/// Poster + title + genres. Fills whatever size its parent gives it: the
/// poster takes the remaining height above the text.
class ShowCard extends StatelessWidget {
  const ShowCard({super.key, required this.show});

  final ShowModel show;

  /// Height reserved below the poster for title and genres (58 at normal text
  /// size, growing with the user's font scale so nothing overflows).
  static double textAreaHeightOf(BuildContext context) =>
      18 + MediaQuery.textScalerOf(context).scale(40);

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () => context.push(AppRoutes.showDetails(show.id), extra: show),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Stack(
              fit: StackFit.expand,
              children: [
                PosterImage(url: show.posterUrl),
                if (show.rating != null)
                  Positioned(
                    left: 6,
                    bottom: 6,
                    child: RatingBadge(rating: show.rating!),
                  ),
                Positioned(
                  top: 6,
                  right: 6,
                  child: WatchlistHeartButton(show: show, iconSize: 16),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: textAreaHeightOf(context) - 8,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  show.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  show.genresLabel ?? 'Genre unavailable',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: textTheme.bodySmall?.copyWith(
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
