import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../core/theme/app_colors.dart';

/// Poster with a loading placeholder and a fallback for missing/broken images.
class PosterImage extends StatelessWidget {
  const PosterImage({
    super.key,
    required this.url,
    this.borderRadius = 14,
    this.alignment = Alignment.center,
  });

  final String? url;
  final double borderRadius;
  final Alignment alignment;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: SizedBox.expand(
        child: url == null
            ? const _PosterFallback()
            : CachedNetworkImage(
                imageUrl: url!,
                fit: BoxFit.cover,
                alignment: alignment,
                memCacheWidth: 400,
                fadeInDuration: const Duration(milliseconds: 200),
                placeholder: (_, __) =>
                    const ColoredBox(color: AppColors.surfaceLight),
                errorWidget: (_, __, ___) => const _PosterFallback(),
              ),
      ),
    );
  }
}

class _PosterFallback extends StatelessWidget {
  const _PosterFallback();

  @override
  Widget build(BuildContext context) {
    return const ColoredBox(
      color: AppColors.surfaceLight,
      child: Center(
        child: Icon(
          Icons.movie_outlined,
          color: AppColors.textMuted,
          size: 32,
        ),
      ),
    );
  }
}
