import '../core/constants/api_constants.dart';
import '../core/network/api_client.dart';
import '../core/network/api_exception.dart';
import '../models/cast_member_model.dart';
import '../models/episode_model.dart';
import '../models/show_model.dart';

/// Talks to the TVMaze show endpoints. Returns models, never raw JSON.
class ShowApiService {
  ShowApiService(this._client);

  final ApiClient _client;

  /// GET /shows?page={page}
  ///
  /// TVMaze answers 404 once [page] is beyond the last page; that is treated
  /// as "no more shows" and returned as an empty list.
  Future<List<ShowModel>> getShows({required int page}) async {
    try {
      final data = await _client.get(
        ApiConstants.shows,
        queryParameters: {'page': page},
      );

      if (data is! List) {
        throw const ApiException('Unexpected response from the server.');
      }

      final shows = <ShowModel>[];
      for (final item in data) {
        if (item is! Map<String, dynamic>) continue;
        try {
          shows.add(ShowModel.fromJson(item));
        } catch (_) {
          // Skip a single malformed entry instead of failing the whole page.
        }
      }
      return shows;
    } on ApiException catch (e) {
      if (e.statusCode == 404) return const [];
      rethrow;
    }
  }

  /// GET /search/shows?q={query}
  ///
  /// The API wraps each hit as `{ "score": ..., "show": {...} }`; results come
  /// back best match first.
  Future<List<ShowModel>> searchShows(String query) async {
    final data = await _client.get(
      ApiConstants.searchShows,
      queryParameters: {'q': query},
    );

    if (data is! List) {
      throw const ApiException('Unexpected response from the server.');
    }

    final shows = <ShowModel>[];
    for (final item in data) {
      if (item is! Map<String, dynamic>) continue;
      final show = item['show'];
      if (show is! Map<String, dynamic>) continue;
      try {
        shows.add(ShowModel.fromJson(show));
      } catch (_) {
        // Skip a single malformed hit.
      }
    }
    return shows;
  }

  /// GET /shows/{id}
  Future<ShowModel> getShowDetails(int id) async {
    final data = await _client.get(ApiConstants.showDetails(id));
    if (data is! Map<String, dynamic>) {
      throw const ApiException('Unexpected response from the server.');
    }
    try {
      return ShowModel.fromJson(data);
    } catch (_) {
      throw const ApiException('Received invalid show data.');
    }
  }

  /// GET /shows/{id}/cast
  Future<List<CastMemberModel>> getShowCast(int id) async {
    try {
      final data = await _client.get(ApiConstants.showCast(id));
      return _parseList(data, CastMemberModel.fromJson);
    } on ApiException catch (e) {
      if (e.statusCode == 404) return const [];
      rethrow;
    }
  }

  /// GET /shows/{id}/episodes
  Future<List<EpisodeModel>> getShowEpisodes(int id) async {
    try {
      final data = await _client.get(ApiConstants.showEpisodes(id));
      return _parseList(data, EpisodeModel.fromJson);
    } on ApiException catch (e) {
      if (e.statusCode == 404) return const [];
      rethrow;
    }
  }

  /// Parses a JSON array, skipping entries that are malformed.
  List<T> _parseList<T>(
    dynamic data,
    T Function(Map<String, dynamic> json) parse,
  ) {
    if (data is! List) {
      throw const ApiException('Unexpected response from the server.');
    }
    final items = <T>[];
    for (final item in data) {
      if (item is! Map<String, dynamic>) continue;
      try {
        items.add(parse(item));
      } catch (_) {
        // Skip a single malformed entry.
      }
    }
    return items;
  }
}
