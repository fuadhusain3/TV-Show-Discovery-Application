import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/show_model.dart';

/// Persists the watchlist on the device with SharedPreferences.
///
/// Whole shows are stored (not just ids) so the watchlist works offline and
/// needs no API calls. Newest entries come first.
class WatchlistLocalService {
  WatchlistLocalService(this._prefs);

  final SharedPreferences _prefs;

  static const String _key = 'watchlist_v1';

  Future<List<ShowModel>> read() async {
    final raw = _prefs.getStringList(_key) ?? const <String>[];

    final shows = <ShowModel>[];
    final seen = <int>{};
    for (final entry in raw) {
      try {
        final json = jsonDecode(entry);
        if (json is! Map<String, dynamic>) continue;
        final show = ShowModel.fromJson(json);
        // Defensive: never surface duplicates, even from old/corrupt data.
        if (seen.add(show.id)) shows.add(show);
      } catch (_) {
        // Skip an unreadable entry instead of losing the whole watchlist.
      }
    }
    return shows;
  }

  Future<void> write(List<ShowModel> shows) async {
    final encoded = [for (final s in shows) jsonEncode(s.toJson())];
    final saved = await _prefs.setStringList(_key, encoded);
    if (!saved) throw Exception('Could not write the watchlist.');
  }
}
